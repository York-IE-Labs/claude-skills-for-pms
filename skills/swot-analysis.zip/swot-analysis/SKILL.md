---
name: swot-analysis
description: Produce a SWOT analysis (Strengths, Weaknesses, Opportunities, Threats) plus strategic recommendations for any subject — a company, competitor, product, initiative, project, career decision, market entry, or personal choice. Use this whenever the user asks for a "SWOT," a "SWOT analysis," to "analyze the pros and cons strategically," to "evaluate strengths and weaknesses," or wants a structured strategic assessment of something they're considering. Also trigger when the user pastes research, notes, or a document about a subject and asks to "assess," "evaluate," or "break down" it strategically, even if they don't say the words "SWOT" explicitly. Research the subject via web search when the user hasn't supplied enough detail themselves.
---

# SWOT Analysis

Produce a clear, well-reasoned SWOT analysis for whatever subject the user gives you — a company, a product, a project, a personal or career decision, a market opportunity, anything. The output is a markdown response in chat, not a file.

## Why this matters

A SWOT analysis is only useful if each item is specific and load-bearing. The most common failure mode is genericness — "strong brand," "competition," "economic uncertainty" — items so vague they could apply to almost any subject and give the reader nothing to act on. Your job is to make every item specific enough that a reader familiar with the subject would nod and say "yes, that's a real, distinct point," not "sure, I guess."

The second most common failure is stopping at the four boxes. A SWOT that just lists items and ends is half-finished — the real value is in the "so what": how do the strengths and opportunities combine into a play, and where do the weaknesses and threats create real exposure. Always finish with strategic recommendations.

## Step 1: Establish the subject and gather context

Figure out what's being analyzed and how much you already know about it.

- If the user pasted in notes, a document, research, or described the subject in detail, work primarily from that — it reflects what they actually care about and may include context you can't get from a search.
- If the subject is a real-world company, product, or public initiative and you don't have enough current, specific information to write substantive items (not just what you recall from training), use web search to fill the gaps — recent news, financials, competitive moves, market conditions. Don't skip this out of laziness; a SWOT built on stale or thin knowledge produces generic filler.
- If the subject is personal (a career move, a personal project, a decision only the user has visibility into), don't research — ask the user directly for the details you're missing rather than guessing at their circumstances.
- If it's ambiguous what's being analyzed (e.g., "do a SWOT on our AI strategy" with no other context), ask a clarifying question before proceeding rather than assuming scope.

## Step 2: Write the four quadrants

Use this structure. Aim for 3-5 items per quadrant — enough to be substantive, not so many that it dilutes into noise.

```markdown
# SWOT Analysis: [Subject]

## Strengths
*Internal, current, positive*
- [Specific, evidenced point]

## Weaknesses
*Internal, current, negative*
- [Specific, evidenced point]

## Opportunities
*External, future-facing, positive*
- [Specific, evidenced point]

## Threats
*External, future-facing, negative*
- [Specific, evidenced point]
```

Keep the internal/external distinction real, not just labeled:
- **Strengths & Weaknesses** are about the subject itself — things it controls or possesses (capabilities, resources, reputation, team, tech, financial position).
- **Opportunities & Threats** are about the environment around the subject — things happening in the market, with competitors, regulation, technology shifts, or customer behavior that the subject doesn't control but is exposed to.

A frequent mistake is writing a weakness that's actually an external threat in disguise (e.g., "increasing competition" isn't a weakness, it's a threat — the weakness might be "no differentiated feature to compete on price pressure"). Push on this distinction rather than letting items blur together.

For each item, favor one sentence that names the specific thing *and* why it matters, over a bare label. "Weak mobile app (2.1 stars, frequent crash reports)" beats "Poor mobile experience."

## Step 3: Strategic recommendations (TOWS cross-analysis)

After the four quadrants, always add a recommendations section that combines them into action. This is what turns a list into a strategy. Use the standard TOWS pairings, but only include a pairing if you have a genuinely useful point to make with it — don't force all four if one is thin:

```markdown
## Strategic Recommendations

**Leverage strengths to capture opportunities (SO)**
- [How a specific strength positions the subject to act on a specific opportunity]

**Use strengths to defend against threats (ST)**
- [How a specific strength can blunt or hedge a specific threat]

**Address weaknesses to pursue opportunities (WO)**
- [What weakness needs fixing before a specific opportunity is actually capturable]

**Minimize weaknesses to avoid threats (WT)**
- [Where a weakness and a threat combine into real risk, and what reduces exposure]
```

Each recommendation should reference the specific quadrant items it's combining, not restate generic strategy advice. If you find yourself writing something that would apply to almost any company in the same situation, go back and make it more specific to this subject.

## Handling thin input

If, after checking the user's input and doing research where appropriate, you still don't have enough to write a substantive item in a quadrant, it's better to write fewer, stronger items than to pad with generic ones.

If the user opts to proceed anyway without giving you the details you'd normally ask for (e.g., they say "just use generic assumptions" or "let's go generic"), don't quietly fill the gaps and present the result as if it were tailored to them — that produces a SWOT that looks specific but is actually invented. Instead:
- State the assumptions you're making up front, in a short line before the quadrants (e.g., "Assumptions used: ..."), so the user can immediately see what's real vs. filled in.
- Where a specific fact would meaningfully change an item (a number, a constraint, a policy), flag it inline in that item rather than silently picking a plausible-sounding value — e.g., "Unknown financial runway (flagged, not assumed) — this is the single most decision-relevant unknown here."

This applies just as much when working from pasted notes or internal context: if the notes leave a real gap (e.g., they describe a mechanism but not its inputs, or a process but not what happens on failure), name that gap explicitly as part of the relevant Weakness or Threat item rather than inventing a plausible-sounding detail to fill it. A flagged gap is more useful to the user than a smoothed-over guess.

## Citations

If you used web search, mention that key facts came from search and that the user should verify anything they plan to rely on for a real decision, per your normal sourcing practice.
