# IT Opportunity Brief Template

Use this template to create a pre-pitch IT intelligence brief for York IE's R&D team.

## Provenance
Adapted from the company-research skill; reoriented for IT consulting pre-pitch intelligence for York IE R&D (2026).

## Template
```markdown
## IT Opportunity Brief: [Company Name]

### Research Objective
- **Company Name:** [Name]
- **Research Purpose:** [Why this research — e.g., "Pre-pitch IT landscape assessment before proposing a software engagement"]
- **Key Questions:**
  - [Question 1 — e.g., "What is the current tech stack and where are the gaps?"]
  - [Question 2 — e.g., "Who are the IT decision-makers and what are they focused on?"]
  - [Question 3 — e.g., "Where can York IE realistically win an engagement?"]

---

### Company Snapshot
**Basic Information:**
- **Name:** [Official company name]
- **Headquarters:** [Location]
- **Industry:** [Primary industry]
- **Founded:** [Year]
- **Size:** [Employees, revenue, locations/business units if relevant]
- **Business Model:** [How they make money]

**IT Environment Context:**
- [Scale and complexity indicators relevant to IT — transaction volume, number of locations, regulated industry, global footprint]

---

### Technology Landscape
**Known Tech Stack:**
- **Cloud & Infrastructure:** [AWS/Azure/GCP posture, on-prem, hybrid]
- **ERP/Back-office:** [SAP, Oracle, NetSuite, Dynamics, custom]
- **CRM & Marketing:** [Salesforce, HubSpot, Adobe, etc.]
- **eCommerce/Customer-facing:** [Platform, apps, APIs]
- **Data & Analytics:** [Warehouse, BI tools, data lake]
- **Integration Layer:** [Known middleware, iPaaS, API gateway — or "None identified"]

**Tech Debt Signals:**
- [Legacy skill postings, delayed migrations, known outages, aging platform references]

---

### Digital & IT Maturity Assessment
**Transformation Stage:** [Manual / Digitizing / Integrated / Data-Driven / Digital-Native]

**Evidence for Rating:**
- [Signal 1 + source]
- [Signal 2 + source]

**Data Maturity:** [Summary — structured data practice vs. siloed/manual reporting]

**AI Readiness:** [Summary — distinguish executive ambition from engineering readiness]

---

### IT Pain Points & Signals
**Job Posting Signals:**
- [Posting 1: role title → what it signals about active projects or gaps]
- [Posting 2: role title → what it signals]

**Leadership Quotes on Tech Frustrations:**
- **[Title]:** "[Quote]"
  - **Source:** [Link], **Date:** [When]
  - **What it signals:** [Brief interpretation for York IE]

**Known Incidents / Press Coverage:**
- [Outage, failed launch, performance failure — cited with source and date]

**Compliance / Regulatory Gaps:**
- [Any known regulatory pressure requiring IT investment]

---

### Key IT Stakeholders
**CTO / VP Engineering:**
- **Name:** [Name or "Not publicly identified"]
- **Background:** [Summary]
- **What they've said publicly:** [Quote or summary + source + date]
- **What to note for York IE:** [Pitch-relevant observation]

**CIO / Head of IT:**
- **Name:** [Name or "Not publicly identified"]
- **Background:** [Summary]
- **What they've said publicly:** [Quote or summary + source + date]
- **What to note for York IE:** [Pitch-relevant observation]

**Other Relevant IT Leaders:**
- [CDO, VP Data, Head of Digital — if relevant to York IE's entry point]

**Stakeholder Landscape:**
- [Centralized IT decision vs. distributed by business unit]
- [Recent leadership changes — new hires often signal openness to new vendors]

---

### Prior Technology Investments
**Known Vendor Relationships:**
- [Vendor — Category — Tenure/Status]
- [Vendor — Category — Tenure/Status]

**Past IT Projects:**
1. **[Project type/name]** — [Summary, announced date, status/outcome]
2. **[Project type/name]** — [Summary, announced date, status/outcome]

**Technology Partner Ecosystem:**
- [Known SIs, MSPs, boutique shops in their ecosystem — and what that means for York IE's positioning]

---

### Opportunity Map

| Opportunity Area | Plausibility | Evidence/Signal |
|---|---|---|
| Custom application development | [H/M/L] | [Signal] |
| Platform / system integration | [H/M/L] | [Signal] |
| Cloud migration | [H/M/L] | [Signal] |
| Data engineering / pipeline | [H/M/L] | [Signal] |
| AI / ML feature development | [H/M/L] | [Signal] |
| Modernization / re-platforming | [H/M/L] | [Signal] |
| QA / testing services | [H/M/L] | [Signal] |
| Product development advisory | [H/M/L] | [Signal] |

**Best-fit entry point for York IE:** [1-2 sentences on the single best opportunity to lead with and why]

---

### Engagement Risk Factors

| Risk Factor | Signal | Severity |
|---|---|---|
| Low IT budget / cost-cutting | [Signal] | H / M / L |
| Just completed major transformation | [Signal] | H / M / L |
| Deep lock-in with large SI | [Signal] | H / M / L |
| Large internal engineering team | [Signal] | H / M / L |
| Regulatory / compliance complexity | [Signal] | H / M / L |
| IT leadership instability | [Signal] | H / M / L |

**Overall Engagement Risk:** [1-2 sentence assessment — high-confidence pitch, speculative opportunity, or pass for now]

---

### IT SWOT Analysis

**Strengths** (internal IT assets — what they have working for them)
- [Strength 1]
- [Strength 2]

**Weaknesses** (gaps, debt, and friction — what's holding them back)
- [Weakness 1]
- [Weakness 2]

**Opportunities** (where York IE can fit their roadmap)
- [Opportunity 1]
- [Opportunity 2]

**Threats** (factors that could block York IE's entry)
- [Threat 1]
- [Threat 2]
```
