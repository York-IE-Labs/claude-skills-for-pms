---
name: company-research
description: Create an IT Opportunity Brief profiling a prospective client's technology landscape, digital maturity, IT pain points, and key stakeholders. Use when evaluating whether and how to pitch software development services to a target company.
intent: >-
  Build a pre-pitch intelligence document that helps York IE's R&D team understand a prospective client's IT environment from the outside. Synthesizes public signals — job postings, earnings call transcripts, press coverage, LinkedIn activity, vendor announcements — into a structured brief covering: technology stack, digital transformation maturity, IT pain points and frustrations, key IT stakeholders, prior technology investments, opportunity areas for York IE, engagement risk factors, and a SWOT analysis. Use before a first client meeting, before writing a pitch, or when evaluating whether a company is a viable software development client.
type: component
theme: research
best_for:
  - "Evaluating a prospective client's IT landscape before a pitch or first meeting"
  - "Identifying where York IE can add value as a software development partner"
  - "Assessing digital transformation maturity and IT risk before proposing an engagement"
scenarios:
  - "Research Acme Corp's tech stack before our first BD call"
  - "Is [Company] a good fit for a custom software engagement? What are their IT challenges?"
  - "Build a pre-pitch brief on [Company] so R&D knows what to propose"
estimated_time: "30-60 min"
---


## Purpose
Create a pre-pitch IT intelligence brief on a prospective client. This document is written for York IE's R&D team — the internal audience evaluating whether and how to pitch software development services.

The output answers: *What is this company's IT environment? Where are they on their digital transformation journey? What are their IT pain points and frustrations? Who are the technology decision-makers? Where can York IE plausibly win a software engagement?*

This is not surface-level research — it is structured intelligence gathering using public signals: job postings, earnings call transcripts, press coverage, vendor partnership announcements, LinkedIn posts from IT leaders, and incident reports.

## Key Concepts

### The IT Opportunity Brief Framework
This framework synthesizes pre-pitch intelligence across nine dimensions:

**Core Sections:**
1. **Company Snapshot:** Industry, size, business model, key markets — enough context to understand what kind of IT environment to expect
2. **Technology Landscape:** Known tech stack, cloud posture, platforms, ERP/CRM systems, tech debt signals, legacy system indicators
3. **Digital & IT Maturity Assessment:** Where the company sits on the transformation curve — manual operations, actively digitizing, or digitally native — plus data maturity and AI readiness
4. **IT Pain Points & Signals:** Job postings signaling gaps, leadership quotes on tech frustrations, known outages or incidents, press coverage of system failures, slow release cycles, compliance gaps
5. **Key IT Stakeholders:** CTO, CIO, VP Engineering, Head of IT — who they are, what they've said publicly, what they're focused on
6. **Prior Technology Investments:** Known vendor relationships, past IT projects, system migrations, significant tech announcements, partner ecosystem
7. **Opportunity Map:** Where York IE could plausibly add value — custom development, platform integration, cloud migration, AI/ML, data engineering, modernization, QA/testing
8. **Engagement Risk Factors:** Signals that suggest this would be a hard sell or risky engagement — low IT budget signals, a transformation just completed, deep lock-in with a competitor, political complexity
9. **IT SWOT Analysis:** Synthesizes sections 2–8 into a strategic frame: Strengths (internal IT assets), Weaknesses (gaps/debt), Opportunities (where York IE fits their roadmap), Threats (lock-in, internal capacity, budget pressures)

### Why This Works
- **IT-centric perspective:** Focuses on infrastructure, engineering org health, and technology decisions — not product strategy or PM culture
- **Consulting lens:** Structured the way a solutions architect or engagement manager thinks before a pitch
- **Tavily-powered:** Uses web search to surface job postings, earnings calls, press coverage, LinkedIn signals, and vendor announcements at each step
- **Actionable output:** The Opportunity Map, Risk Factors, and SWOT directly inform what York IE should and should not propose

### Anti-Patterns (What This Is NOT)
- **Not a competitive analysis:** This profiles a prospective *client*, not a competitor
- **Not a financial deep-dive:** IT landscape, not valuation or P&L
- **Not surface scraping:** "They use Salesforce" is not enough. Find the friction — what isn't working, what's been announced but not delivered, what the CTO is complaining about publicly
- **Not a product strategy review:** York IE is evaluating an IT services engagement, not a PLG playbook

### When to Use This
- Before a first business development call with a prospective client
- Before writing a pitch or proposal for IT services
- When the R&D team is evaluating a prospect's fit for a software engagement
- When scoping what services to propose

### When NOT to Use This
- For competitive analysis of companies in a *client's* market (use a different research frame)
- When the prospect has already shared their IT environment directly (use that input instead)
- As a substitute for a discovery call — this is pre-call intelligence, not a replacement for direct conversation

---

## Application

Use `template.md` for the full fill-in structure.

### Research Approach

Use the **Tavily MCP search tool** to gather intelligence at each step below. Begin with a broad sweep before diving into section-specific queries:

```
tavily_research "[Company Name] IT landscape digital transformation technology"
```

Then run targeted `tavily_search` queries as prompted in each step. Always verify Tavily results against primary sources (company website, investor relations, LinkedIn).

---

### Step 1: Define Research Scope

Clarify what you're researching and why:

```markdown
## Research Objective
- **Company Name:** [e.g., "Foot Locker, Inc."]
- **Research Purpose:** [e.g., "Evaluate IT landscape before pitching a custom eCommerce integration build"]
- **Key Questions:**
  - [Question 1: e.g., "What does their current tech stack look like, and where are the gaps?"]
  - [Question 2: e.g., "Who are the IT decision-makers and what are they focused on?"]
  - [Question 3: e.g., "Where could York IE realistically win a software engagement?"]
```

---

### Step 2: Gather Company Snapshot

Document basic company information and IT environment context:

```markdown
### Company Snapshot

**Basic Information:**
- **Name:** [Official company name]
- **Headquarters:** [Location]
- **Industry:** [Primary industry — important: industry shapes expected IT complexity]
- **Founded:** [Year]
- **Size:** [Employees, revenue, number of locations/business units if relevant]
- **Business Model:** [How they make money — product, SaaS, services, retail, manufacturing, etc.]

**IT Environment Context:**
- [Scale and complexity indicators relevant to IT — transaction volume, number of locations, regulated industry, global footprint]
- [What does a company of this type/size typically look like from an IT perspective?]
```

**Tavily queries:**
```
tavily_search "[Company] company overview annual revenue employees"
tavily_search "[Company] business model locations"
```

**Additional sources:** Company website (About, Investor Relations), LinkedIn, Wikipedia, 10-K / annual report.

---

### Step 3: Map the Technology Landscape

Identify the known tech stack and flag tech debt signals:

```markdown
### Technology Landscape

**Known Tech Stack:**
- **Cloud & Infrastructure:** [AWS/Azure/GCP posture, on-prem vs. cloud, hybrid]
- **ERP/Back-office:** [SAP, Oracle, NetSuite, Dynamics, custom — and version if known]
- **CRM & Marketing:** [Salesforce, HubSpot, Adobe Experience Cloud, etc.]
- **eCommerce/Customer-facing:** [Platforms, APIs, mobile apps]
- **Data & Analytics:** [Warehouse, BI tools, data lake presence]
- **Integration Layer:** [Known middleware, iPaaS, API gateway, or lack thereof]

**Tech Debt Signals:**
- [Signs of aging systems: old job postings for legacy skills (COBOL, AS/400, on-prem Oracle)]
- [References to "system migrations" that have been delayed or announced multiple times]
- [Press coverage of outages or performance failures]
```

**Tavily queries:**
```
tavily_search "[Company] tech stack ERP CRM platform"
tavily_search "[Company] engineering blog technology"
tavily_search "[Company] SAP Oracle Salesforce implementation"
tavily_search "[Company] IT modernization legacy system"
```

**Additional sources:** Job postings (BuiltWith, Stackshare, Greenhouse/Workday careers page), G2 reviews, press releases mentioning tech vendors, Glassdoor reviews mentioning systems frustrations.

---

### Step 4: Assess Digital & IT Maturity

Rate the company on the five-level transformation scale and justify with evidence:

```markdown
### Digital & IT Maturity Assessment

**Transformation Stage:** [Choose one and justify]
1. **Manual** — Core operations run on spreadsheets, paper, or point solutions. No integrated systems.
2. **Digitizing** — Actively replacing manual processes. ERP or CRM in place but not fully adopted. Significant tech debt.
3. **Integrated** — Core systems connected. Some automation. Beginning to invest in data and analytics.
4. **Data-Driven** — Decisions driven by data. Modern stack. Engineering org of meaningful size.
5. **Digital-Native** — Technology is a core competitive differentiator. Continuous delivery, cloud-first, AI-enabled.

**Evidence for Rating:**
- [Signal 1 + source]
- [Signal 2 + source]

**Data Maturity:** [Signs of structured data practice vs. siloed/manual reporting]

**AI Readiness:** [Distinguish executive AI ambition from engineering readiness — look for data infrastructure, ML roles, or AI platform investments, not just CEO statements]
```

**Tavily queries:**
```
tavily_search "[Company] digital transformation strategy"
tavily_search "[Company] IT modernization cloud migration"
tavily_search "[Company] data analytics AI machine learning"
```

**Quality check:** Executive AI statements ≠ AI readiness. Look for engineering signals (data engineering roles, ML platform investments, data science team) before rating AI readiness above Low.

---

### Step 5: Document IT Pain Points & Signals

Surface concrete evidence of IT friction — this is the foundation of York IE's pitch:

```markdown
### IT Pain Points & Signals

**Job Posting Signals:**
- [Posting 1: what it signals — e.g., "Hiring Senior Integration Engineer (SAP ↔ Salesforce): confirms ERP/CRM integration gap"]
- [Posting 2: what it signals]

**Leadership Quotes on Tech Frustrations:**
- **[Title]:** "[Quote]"
  - **Source:** [Link], **Date:** [When]
  - **What it signals:** [Brief interpretation — why this matters for York IE]

**Known Incidents / Press Coverage:**
- [Outage, failed launch, performance failure — cited with source and date]
- [e.g., "Q3 2023 earnings call: CEO attributed 3% revenue miss to 'platform instability during peak season'"]

**Compliance / Regulatory Gaps:**
- [Any known regulatory pressure requiring IT investment — HIPAA, PCI-DSS, SOC 2, GDPR, etc.]
```

**Tavily queries:**
```
tavily_search "[Company] IT outage system failure platform issues"
tavily_search "[Company] CTO interview technology challenges 2024"
tavily_search "[Company] digital platform problems press coverage"
tavily_search "[Company] compliance HIPAA PCI SOC2 regulatory"
```

**Additional sources:** LinkedIn job postings, Glassdoor reviews, earnings call transcripts (via investor relations page), industry press (TechCrunch, The Register, VentureBeat).

---

### Step 6: Profile Key IT Stakeholders

Identify the decision-makers York IE needs to reach:

```markdown
### Key IT Stakeholders

**CTO / VP Engineering:**
- **Name:** [If identified, or "Not publicly identified"]
- **Background:** [Relevant experience]
- **What they've said publicly:** [Quote or summary + source + date]
- **What to note for York IE:** [Pitch-relevant observation — what they care about, their focus area]

**CIO / Head of IT:**
- **Name:** [If identified]
- **Background:** [Relevant experience]
- **What they've said publicly:** [Quote or summary + source + date]
- **What to note for York IE:** [Pitch-relevant observation]

**Other Relevant IT Leaders:**
- [CDO / Chief Data Officer — if data engineering is the opportunity]
- [Head of Digital / Chief Digital Officer — if digital transformation is the entry point]
- [Note: In mid-market companies, one person may hold CTO+CIO responsibilities]

**Stakeholder Landscape:**
- [Is this a centralized IT decision or distributed by business unit?]
- [Signs of IT/business tension (business wants speed, IT wants stability)?]
- [Recent leadership changes — new CTO/CIO often signals openness to new vendors]
```

**Tavily queries:**
```
tavily_search "[Company] CTO Chief Technology Officer"
tavily_search "[Company] CIO Chief Information Officer"
tavily_search "[Company] VP Engineering technology leadership"
tavily_search "[Company] Chief Digital Officer CDO"
```

---

### Step 7: Catalog Prior Technology Investments

Understand what vendors, SIs, and projects are already in play:

```markdown
### Prior Technology Investments

**Known Vendor Relationships:**
- [Vendor, category, tenure/status — e.g., "SAP ERP: in place since ~2015, likely on ECC 6.0"]
- [Note: Long-standing vendor relationships signal switching cost; recent changes signal openness to new partners]

**Past IT Projects (Announced or Completed):**
1. **[Project type/name]** — [Summary, announced date, status/outcome]
   - [Example: "2022: Announced migration from on-prem Oracle to SAP S/4HANA. 2024: CIO described as 'ongoing' — suggests delays"]
2. **[Project type/name]** — [Summary, timeline, outcome]

**Technology Partner Ecosystem:**
- [Known SIs (Accenture, Wipro, Cognizant), boutique shops, or managed service providers]
- [This tells you who you'd be competing with or complementing]
```

**Tavily queries:**
```
tavily_search "[Company] technology partner implementation SAP Salesforce"
tavily_search "[Company] IT project migration announcement"
tavily_search "[Company] Accenture Deloitte Wipro Cognizant partner"
tavily_search "[Company] systems integrator consulting"
```

---

### Step 8: Build the Opportunity Map

Rate each opportunity area with evidence — be honest about Low ratings:

```markdown
### Opportunity Map

| Opportunity Area | Plausibility | Evidence/Signal |
|---|---|---|
| Custom application development | [H/M/L] | [Signal from job postings, engineering team size, or project backlog signals] |
| Platform / system integration | [H/M/L] | [Signal from known disconnected systems, integration engineer postings, or SI gap] |
| Cloud migration | [H/M/L] | [Signal from on-prem indicators, CIO cloud-first statements, or hybrid posture] |
| Data engineering / pipeline | [H/M/L] | [Signal from data engineer postings, BI tool investments, or data silo language] |
| AI / ML feature development | [H/M/L] | [Signal from ML roles, data science team, or AI platform investment — not CEO statements alone] |
| Modernization / re-platforming | [H/M/L] | [Signal from legacy system age, acquisition-era tech debt, or migration language] |
| QA / testing services | [H/M/L] | [Signal from known quality failures, no QA roles visible, or release instability press coverage] |
| Product development advisory | [H/M/L] | [Signal from no PM org visible, or engineering-led company without product discipline] |

**Best-fit entry point for York IE:**
[1-2 sentences: based on the above, the single most compelling opportunity to lead with in a pitch, and why]
```

---

### Step 9: Assess Engagement Risk Factors

Surface risks before walking into a pitch:

```markdown
### Engagement Risk Factors

| Risk Factor | Signal | Severity |
|---|---|---|
| Low IT budget / cost-cutting mode | [e.g., "Headcount reductions in last 6 months; IT budget language in earnings call"] | H / M / L |
| Just completed a major transformation | [e.g., "SAP go-live announced Q1 2024 — likely in stabilization mode, not new projects"] | H / M / L |
| Deep lock-in with a large SI | [e.g., "Accenture named as primary SI partner in press release"] | H / M / L |
| Large internal engineering team | [e.g., "500+ engineers on LinkedIn — strong internal delivery capability"] | H / M / L |
| Regulatory / compliance complexity | [e.g., "Healthcare company — HIPAA compliance adds project overhead"] | H / M / L |
| IT leadership instability | [e.g., "Three CIOs in 24 months — instability signals political risk"] | H / M / L |

**Overall Engagement Risk Assessment:**
[1-2 sentences: high-confidence pitch, speculative opportunity, or pass for now — and why]
```

**Tavily queries:**
```
tavily_search "[Company] layoffs cost cutting IT budget 2024"
tavily_search "[Company] CIO CTO departure leadership change"
```

---

### Step 10: IT SWOT Analysis

Synthesize sections 2–9 into a strategic frame for York IE's pitch planning:

```markdown
### IT SWOT Analysis

**Strengths** (internal IT assets — what they have working for them)
- [e.g., "Modern cloud data warehouse (Snowflake) — data foundation is in place"]
- [e.g., "Engineering team of ~150 signals delivery capacity exists"]
- [e.g., "Active digital transformation program with allocated budget"]

**Weaknesses** (gaps, debt, and friction — what's holding them back)
- [e.g., "No integration layer between SAP and Salesforce SFCC — manual data reconciliation likely"]
- [e.g., "Legacy POS systems across 3,000+ stores — high integration complexity"]
- [e.g., "IT leadership gap (CTO departure) — procurement decisions in flux"]

**Opportunities** (where York IE can fit their roadmap)
- [e.g., "SAP ↔ Salesforce integration is a funded, in-progress need with no clear delivery owner"]
- [e.g., "QA/testing for high-traffic release events is a known gap with a measurable ROI story"]
- [e.g., "Data pipeline modernization to support CDO's analytics roadmap"]

**Threats** (factors that could block York IE's entry)
- [e.g., "Deloitte may already be engaged on SAP work — compete or complement?"]
- [e.g., "Internal engineering team may be tasked to self-deliver integration work"]
- [e.g., "Budget freeze risk if transformation costs overrun — verify current project status"]
```

---

## Examples

See `examples/sample.md` for a full IT Opportunity Brief example using Foot Locker, Inc.

Mini example excerpt:

```markdown
**Company Name:** Foot Locker, Inc.
**Research Purpose:** Evaluate IT landscape before pitching platform integration and QA services
**Key Questions:** What does their SAP + Salesforce stack look like end-to-end? Who owns IT post-CTO departure? Where's the integration gap?
```

## Common Pitfalls

### Pitfall 1: Stack-Listing Instead of Signal-Reading
**Symptom:** "They use Salesforce and AWS."

**Consequence:** Tells you what they have, not where the pain is. No pitch angle.

**Fix:** Every stack item needs a maturity or friction signal. "They use SAP — and based on the 2023 CIO interview mentioning 'migration delays', they're likely mid-implementation, not post-stabilization. That's a York IE entry point."

---

### Pitfall 2: Ignoring Job Postings as Primary Research
**Symptom:** Job postings not consulted.

**Consequence:** Job postings are the richest free signal for active IT projects, skill gaps, and running systems. Missing them means missing the intelligence.

**Fix:** Always run `tavily_search "[Company] jobs software engineer integration"` and check the company's careers page directly. Read full job descriptions — the tech stack and project context are in the requirements.

---

### Pitfall 3: Over-Rating AI Readiness
**Symptom:** "They mentioned AI in their annual report — they're ready for an AI engagement."

**Consequence:** Executive AI ambition ≠ engineering readiness. Companies frequently announce AI intent 2-3 years before they have the data infrastructure or team to execute.

**Fix:** Separate AI ambition (CEO statements) from AI readiness (data engineering roles, ML platform investment, data science headcount). Only rate AI readiness above Low if engineering signals are present.

---

### Pitfall 4: Missing the Risk Factors
**Symptom:** Opportunity Map looks strong, no risk flags raised.

**Consequence:** Walking into a pitch without knowing the company just signed a 5-year SI contract, or is in cost-cutting mode, or has 500 internal engineers who view outside vendors as a threat.

**Fix:** Always complete Step 9 (Engagement Risk Factors). A medium-confidence opportunity with surfaced risks is more useful than an inflated pitch with no flags.

---

### Pitfall 5: No Source Citations
**Symptom:** "The CTO said the company is focused on modernization."

**Consequence:** Unverifiable, low credibility. Can't verify timing or context.

**Fix:** Always cite source and date: "The CTO said X (Source: [Company] Investor Day transcript, Q3 2023)."

---

## References

### Related Skills
- `skills/york-ie-research-brief/SKILL.md` — Orchestrates company research into a full research brief for B2B SaaS advisory
- `skills/scope-of-work/SKILL.md` — Uses opportunity brief as context when defining engagement scope
- `skills/requirement-gathering/SKILL.md` — Next step after a prospect becomes a client

### External Frameworks
- ThoughtWorks Technology Radar — Useful for benchmarking stack currency
- Gartner IT Score methodology — Reference for IT maturity assessment
- IDC Digital Transformation maturity model — Reference for transformation stage ratings

### Provenance
- Adapted from `prompts/company-profile-executive-insights-research.md` in the `https://github.com/deanpeters/product-manager-prompts` repo; reoriented for IT consulting pre-pitch intelligence by York IE R&D team (2026).

---

**Skill type:** Component
**Suggested filename:** `company-research.md`
**Suggested placement:** `/skills/components/`
**Dependencies:** May feed into `skills/york-ie-research-brief/SKILL.md`
