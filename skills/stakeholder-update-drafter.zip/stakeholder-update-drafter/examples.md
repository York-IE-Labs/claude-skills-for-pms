# Examples

Use these as quality targets, not copy-paste text. Invented company details below are fictional.

## 1. Executive + Email

**Notes (raw):**
```
- checkout v2 live for 20% of US traffic, conversion +2.1% vs control so far
- still waiting on legal for EU terms (asked 2 weeks ago, same as last update)
- mobile wallet in QA, aiming to ship next Thu
- risk: if legal slips past Friday we miss the EU launch window
- need exec call on whether to delay EU or ship US-only
```

**Draft:**

```
Subject: Checkout v2 live in US; EU launch blocked on legal

Checkout v2 is live for 20% of US traffic and is tracking 2.1% higher conversion vs control. EU launch remains blocked on legal review of terms — this is the second cycle with no decision. If terms are not approved by Friday, we miss the EU window and should ship US-only. Mobile wallet is in QA and ships next Thursday. Ask: decide by Friday whether to hold EU or proceed US-only.
```

## 2. Engineering + Slack

**Notes (raw):**
```
shipped: feature flag cleanup on payments-api, dropped unused stripe_legacy path
wip: replay worker lag — catching up after Tuesday deploy, p95 12s → 4s, still not at 1s SLO
blocked: waiting on platform for redis cluster resize (ticket PLAT-441, opened last sprint, still open)
dep: can't start idempotency keys until resize lands
next: resize then idempotency keys; load test Friday
```

**Draft:**

```
*Payments-api flag cleanup shipped; replay lag improving, still blocked on Redis resize*

*Shipped*
- Removed unused `stripe_legacy` path behind flags on payments-api

*In progress*
- Replay worker lag after Tuesday deploy: p95 12s → 4s, still above 1s SLO

*Blockers / risks*
- *STALE (2 cycles):* Redis cluster resize (PLAT-441). Needed to start idempotency keys. Needs Platform to complete the resize.

*What's next*
- After resize: idempotency keys, then load test Friday
```

## 3. Cross-functional/Mixed + Email

**Notes (raw):**
```
- search relevance model (new ranking) in 10% experiment
- design signed off on empty-state illustrations
- support docs not started — need a writer this week or we launch without them
- product wants to expand experiment to 50% Friday if p95 latency stays <200ms
- eng: latency currently ~180ms
- sales asked if they can mention it on calls — not yet, wait for 50%
```

**Draft:**

```
Subject: Search ranking experiment at 10% — docs are the launch gap

New search ranking (the model that orders results) is in a 10% experiment; latency is ~180ms, under the 200ms bar Product set for a Friday expansion to 50%.

Shipped
- Design signed off on empty-state illustrations

In progress
- Ranking experiment at 10%. Product will expand to 50% Friday if latency stays under 200ms.
- Support docs have not started.

Blockers / risks
- Docs: launch will ship without help-center coverage unless a writer is assigned this week. Needed: writer assigned by Wednesday.

What's next
- Friday: expand experiment to 50% if the latency bar holds
- Sales: do not mention the new ranking on calls until the 50% expansion

Ask
- Staff a writer this week so Support has docs before the 50% expansion
```

## 4. Missing audience — ask first

If the user pastes notes with no audience or channel, ask once:

> Audience: Executive, Engineering, or Cross-functional/Mixed?
> Format: Email or Slack?

Then draft. Do not produce a generic update "for everyone."

## Anti-examples (do not do this)

**Hedging filler:**
> Just wanted to check in with a quick update. We might be able to ship next week if things go well.

**Executive jargon dump:**
> The payments-api stripe_legacy path was removed and PLAT-441 is still open on the Redis cluster so idempotency keys are blocked.

**Buried stale blocker:**
> Also, still waiting on legal, as mentioned last time.
