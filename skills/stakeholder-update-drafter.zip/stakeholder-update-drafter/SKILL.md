---
name: stakeholder-update-drafter
description: >-
  Turns raw sprint or project status notes into a polished stakeholder update.
  Adapts tone, detail, and jargon for Executive, Engineering, or Cross-functional/Mixed
  audiences and formats as Email (with subject line) or Slack post. Use when the
  user asks to draft a stakeholder update, status update, sprint update, project
  update, exec update, or to turn messy notes, bullets, or standup notes into an
  email or Slack post.
---

# Stakeholder Update Drafter

Draft a polished status update from messy notes. Do not invent facts, dates, owners, metrics, or decisions that are not in the notes or conversation.

## Workflow

1. **Collect inputs.** Need notes plus audience and format. Infer from context when obvious (e.g. "send to leadership" → Executive + Email; "post in #eng" → Engineering + Slack). If either is missing and cannot be inferred, ask once:
   - Audience: Executive | Engineering | Cross-functional/Mixed
   - Format: Email | Slack
2. **Parse notes** into: shipped/wins, in progress, blockers, risks, upcoming milestones, and any ask (decisions or help needed).
3. **Detect stale blockers.** Flag any blocker open for more than one reporting cycle so it doesn't get buried. Treat as stale if notes say "still", "same as last week/sprint", "ongoing", a date older than one cycle, or a prior update in the thread listed the same blocker. If duration is unclear, ask once whether any blocker carried over. Prefix stale items with **STALE** (and how long, if known).
4. **Draft** using the audience rules and the matching format template.
5. **Quality check** against the tone rules before sending the draft.

## Audience

Adapt tone, detail level, and jargon:

- **Executive:** lead with business impact and risk, minimal technical detail, 4-6 sentences max, no jargon.
- **Engineering:** lead with technical status, blockers, and dependencies, can use technical terms freely.
- **Cross-functional/Mixed:** balanced tone, explain technical terms briefly, focus on what changes for each team.

### Executive compression

The entire body (excluding subject line and optional Ask) is 4-6 sentences. Fold the required structure into that narrative; do not use long bullet lists. Still cover wins, in progress, blockers/risks (with unblock path), and what's next. No unexplained acronyms or system names.

### Engineering

Lead with technical status, then blockers and dependencies. Full section headers and bullets. Include owners, PRs, services, and env details when present in the notes.

### Cross-functional/Mixed

Balanced tone. On first use of a technical term, add a short plain-language gloss in parentheses. Emphasize what changes for each team (eng, product, design, GTM, support, etc.) when that is knowable from the notes.

## Required structure

Always include, in this order (compress into sentences for Executive):

1. **Headline summary (1 line)** — the one thing the audience should remember.
2. **Wins/shipped this period**
3. **In progress**
4. **Blockers/risks** — each item includes what's needed to unblock
5. **What's next** — upcoming milestones with timing if known

Omit a section only when there is no source material. Do not pad with filler. Do not write "no blockers" unless the notes say so or the user confirms.

**Ask (optional):** End with an Ask section only if the user has any decisions/help needed from the audience. Skip it when there is no ask. Each ask is a single concrete request with owner context if known (who needs to decide/do what, by when).

## Format

### Email

- First line: `Subject: ...` — specific, scannable, no "Status update" alone. Include team/project and timeframe when known.
- Greeting optional and short (`Hi team,` / `Hi [Name],`). No preamble.
- Executive: short paragraphs totaling 4-6 sentences.
- Engineering / Cross-functional: headline, then the section headers below.
- Sign-off: name only if present in context; otherwise omit.

### Slack

Shorter than email. Casual but still confident. Use headers and bullets. No subject line, no greeting, no sign-off.

```
*[Headline summary]*

*Shipped*
- ...

*In progress*
- ...

*Blockers / risks*
- ...

*What's next*
- ...

*Ask*   ← only if needed
- ...
```

Mark stale blockers in Slack as `*STALE (2 cycles):*` at the start of the bullet.

## Tone

Keep the tone confident and clear — no hedging language, no filler phrases like "just wanted to check in."

Ban these (and close variants): just wanted to check in, wanted to give a quick update, circling back, looping in, hope this finds you, I think, maybe, hopefully, we should be able to, might, perhaps, kind of, sort of, trying to, it seems, at a high level, going forward we'll try.

Prefer direct verbs: shipped, blocked on, needs, ships on, decided, cut, delayed until.

Do not apologize for the update existing. Do not oversell. If something slipped, say so in one clause and state the new date or next action.

## Guardrails

- Never invent progress, dates, or owners.
- Never bury a stale blocker at the bottom of a long list — put stale blockers first in the Blockers/risks section.
- If notes mix personal asides, jokes, or confidential HR/personnel detail, drop them unless they are the actual status.
- If a number or date is ambiguous, keep the wording from the notes or ask; do not round or guess.
- Output only the draft (plus a one-line note if you inferred audience/format or flagged a stale blocker from incomplete info). Do not explain the skill.

## Additional resources

- Worked examples for each audience and format: [examples.md](examples.md)
