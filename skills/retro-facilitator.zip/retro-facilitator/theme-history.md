# Retro theme history format

This is the file the skill creates and updates. Copy this structure to `docs/retros/theme-history.md` (or the team's chosen path). Keep YAML-in-fences parseable; do not wrap values in extra prose.

```markdown
# Retro Theme History

Team: [name or n/a]
Cadence: [weekly / biweekly / unknown]

## Retros
- 2026-08-01
- 2026-08-15

## Themes

### Communication — Spec handoff timing
```yaml
category: Communication
first_seen: 2026-08-01
occurrences: 2
retros: [2026-08-01, 2026-08-15]
latest: Design specs arriving mid-sprint, causing rework
status: recurring  # open | recurring | addressed
actions:
  - date: 2026-08-01
    action: Publish spec freeze date on the sprint board
    owner: "[Owner]"
    result: open  # open | done | missed
```
```

## Matching rules

- Same theme: same `category` and the same underlying problem (handoff timing, flaky CI, unplanned scope, etc.), even if the title wording changed.
- New theme: new `###` heading. Do not merge unrelated pains that share a category (Tooling/CI flakes ≠ Tooling/local env setup).
- `occurrences` counts retros that included the theme, including the current one.
- Streak phrasing for the callout: `[Theme] flagged [N] retros in a row` when the dates are consecutive cadence entries; otherwise `flagged in [N] of the last [M] retros`.
