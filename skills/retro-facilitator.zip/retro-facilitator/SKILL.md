---
name: retro-facilitator
description: >-
  Structures raw retro input into a clean retro doc, suggests owned action items,
  tags themes by category, and tracks recurring themes across retros over time.
  Use when the user pastes retro notes, sticky-note dumps, a retro transcript,
  or asks to facilitate a retro, write up a retrospective, or compare this retro
  to previous ones.
---

# Retro Facilitator

Turn raw, unstructured retro input into a clean markdown retro doc. Neutral and blame-free: describe the situation and impact, not the person. Do not invent events. Owners and due dates that were not stated become placeholders.

## Inputs

Need at least one of: sticky-note dump, meeting transcript, or bullet points from multiple people.

Also load theme history when present:

1. A previous retro doc or theme history the user attached or @-mentioned
2. Else search the workspace for `docs/retros/theme-history.md`, `retros/theme-history.md`, `.cursor/retro-theme-history.md`, or files matching `*theme-history*`
3. If none exists, proceed without a Recurring Themes callout, then create history at the default path (see Persist)

Ask once for a date/team name only if they are not inferable.

## Workflow

Run these steps in order.

### Step 1 — Organize

Organize the raw input into three sections: What went well, What didn't go well, Action items — deduplicating similar points and grouping related comments together under one theme.

- Merge restated stickies into one theme with a short title.
- Keep 1–3 concrete supporting bullets per theme (paraphrase; do not quote angrily).
- Drop jokes, names used as blame, and off-topic asides.
- Action items already stated in the notes go to Action items; still keep the related pain under What didn't go well.

### Step 2 — Fill missing actions

For each item in "What didn't go well," suggest a concrete, owned action item if one wasn't already stated (format: Action - Owner - Due date placeholder).

- Action: one verb phrase the team can complete in a single sprint (change a process, add a check, schedule a conversation, set a limit).
- Owner: named person from the notes, else `[Owner]`.
- Due date: stated date, else `[Due date]`.
- Do not invent a person. Do not create actions for What went well.

### Step 3 — Tag categories

Tag each theme with a short category label (e.g., Communication, Process, Tooling, Scope, Technical Debt) to make patterns easier to spot over time.

Reuse an existing label when it fits. Add a new short label only when none of the examples apply (e.g., Hiring, On-call). One primary category per theme.

### Step 4 — Recurring themes

If given a previous retro doc or theme history alongside the new input, compare them and flag any recurring themes across retros (e.g., "Communication gaps with design flagged 3 retros in a row") so the same issue doesn't keep resurfacing unaddressed.

Match on category + similar problem, not exact wording. A theme is recurring if it appears in 2+ retros, including this one. Put **Recurring Themes** at the top of the doc when history was available and at least one match exists. If history was provided and nothing recurs, omit the callout (do not write "none").

Note in the callout whether a prior action on that theme was missed, still open, or done-but-the-pain-returned.

## Output

A clean markdown doc with headers for each section, plus a short "Recurring Themes" callout at the top if history was provided.

```markdown
# Retro — [Team or project] — [YYYY-MM-DD]

## Recurring Themes
> **[Category]:** [one-line flag, including streak count]
> Prior action: [done / open / missed] — [what was tried, if known]

## What went well
### [Theme title] `[Category]`
- [situation and impact]

## What didn't go well
### [Theme title] `[Category]`
- [situation and impact]
- Suggested action: [Action] - [Owner] - [Due date]

## Action items
| Action | Owner | Due date | Category |
|---|---|---|---|
| ... | ... | ... | ... |
```

Rules:

- Suggested actions from Step 2 appear both under the pain theme and in the Action items table. Deduplicate rows.
- Recurring Themes is only the callout plus one quoted line per streak — not a fourth dump of the retro.
- Keep language neutral and blame-free — describe the situation and impact, not the person. Rewrite "X dropped the ball" → "Y did not happen, which caused Z."

## Persist theme history

After the doc, accumulate history so later retros can compare.

**Default file:** `docs/retros/theme-history.md` in the current project. If the user already has a history file, update that path instead. If there is no project workspace, ask once where to keep history (or write beside an existing retro doc they opened).

Also save the retro doc itself as `docs/retros/YYYY-MM-DD.md` (or next to the history file) unless the user only wanted a chat draft.

History file format is in [theme-history.md](theme-history.md). On each run:

1. Create the file from that template if it does not exist.
2. Append this retro to `## Retros`.
3. For each theme this retro: increment `occurrences`, add today's date to `retros`, refresh `latest`, set `status` to `recurring` if occurrences ≥ 2 and the pain is still present.
4. If a prior action for that theme is now done and the pain did not recur, set `status: addressed`.
5. Do not delete old themes; they are the streak record.

Then output the retro doc. Mention the history path in one line.

## Guardrails

- Do not name people except as action owners they volunteered for, or when the notes assign ownership.
- Do not add metrics, quotes, or root causes that are not in the input.
- Prefer fewer, stronger themes over a long ungrouped list.
- If input is too thin to group, keep the items and still tag categories.

## Additional resources

- History file format: [theme-history.md](theme-history.md)
- Worked examples: [examples.md](examples.md)
