# Examples

Fictional team. Use as quality targets, not copy-paste output.

## 1. Sticky dump → clean doc (no history)

**Input:**
```
went well: ship day felt calm, qa caught the checkout bug early, standup shorter
bad: too many mid-sprint "quick asks" from sales, ci red for 2 days nobody knew who owned it,
alex never updated the ticket (skip names), design files landed thursday
actions: maybe we need a freeze? someone should own ci
```

**Draft (excerpt):**

```markdown
# Retro — Payments — 2026-08-15

## What went well
### Calm ship day `[Process]`
- Release day stayed predictable; QA caught the checkout bug before production.

### Tighter standups `[Process]`
- Standups ran shorter, which left more focus time.

## What didn't go well
### Unplanned sales requests mid-sprint `[Scope]`
- Mid-sprint "quick asks" landed after planning, which displaced committed work.
- Suggested action: Add a same-sprint intake rule (defer or explicitly swap scope) - [Owner] - [Due date]

### CI failures with unclear ownership `[Tooling]`
- CI stayed red for two days with no named owner, which blocked merges.
- Suggested action: Assign a rotating CI owner on the sprint board - [Owner] - [Due date]

### Design files arriving late `[Communication]`
- Design files landed Thursday, which compressed implementation and review.
- Suggested action: Set a mid-sprint design-drop cutoff on the board - [Owner] - [Due date]

## Action items
| Action | Owner | Due date | Category |
|---|---|---|---|
| Add a same-sprint intake rule (defer or explicitly swap scope) | [Owner] | [Due date] | Scope |
| Assign a rotating CI owner on the sprint board | [Owner] | [Due date] | Tooling |
| Set a mid-sprint design-drop cutoff on the board | [Owner] | [Due date] | Communication |
```

Note: "alex never updated the ticket" is folded into CI ownership as situation/impact — no name in the doc.

## 2. With history → Recurring Themes callout

**History already has** Communication / Spec handoff timing, occurrences: 2, last two retros.

**New notes include:** "design still coming in late, third time"

**Top of doc:**

```markdown
## Recurring Themes
> **Communication:** Design handoff arriving late flagged 3 retros in a row
> Prior action: open — spec freeze date on the board was agreed last retro and is not in use
```

Then write the rest of the doc as usual, and set that theme's `occurrences: 3`, `status: recurring`.

## 3. Pain returned after a done action

Prior action `result: done`, but the same pain is in this retro:

```markdown
## Recurring Themes
> **Tooling:** Flaky CI flagged in 3 of the last 4 retros
> Prior action: done-but-returned — quarantine job was added; flakes are back on the deploy pipeline
```

Do not mark the theme `addressed`. Keep `status: recurring` and add a new action row.

## 4. Anti-examples (do not do this)

**Blame:**
> Alex blocked the team by not watching CI.

**Use instead:**
> CI stayed red for two days with no named owner, which blocked merges.

**Ungrouped dump:** 12 one-line stickies instead of 4 themes.

**Invented owner:** filling `[Owner]` with a guessed name from unrelated chat context.
