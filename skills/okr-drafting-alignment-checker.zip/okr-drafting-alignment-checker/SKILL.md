---
name: okr-drafting-alignment-checker
description: >-
  Drafts Objectives and Key Results from a rough goal and validates KR quality:
  measurable metric, outcome not output, tied to the Objective, team-influenceable,
  and baseline-to-target. Use when the user asks to draft OKRs, write objectives
  and key results, check OKR quality, score KRs, or align team OKRs to a company
  objective.
---

# OKR Drafting & Alignment Checker

Draft 1 Objective and 2–4 Key Results from a rough goal, then validate every KR. Do not invent baselines, targets, owners, or company strategy. Use `[baseline]`, `[target]`, and `[date]` when a number is required but unknown.

## When to ask first

If the input is too vague to draft a good Objective, ask one clarifying question before proceeding instead of guessing.

Ask when any of these are missing and block a non-generic Objective: what should be different if we succeed, for whom, or by when. One question only — pick the highest-leverage gap. Do not ask if the goal is specific enough to draft with placeholders.

## Workflow

### Step 1 — Draft

Draft 1 Objective (qualitative, inspiring, time-bound, not a task) and 2-4 Key Results (quantitative, measurable, outcome-based — not output/activity-based).

**Objective**

- Qualitative: direction and ambition, not a metric and not a to-do ("Ship v2", "Write the RFC").
- Inspiring: a change in customer, business, or system state worth caring about.
- Time-bound: include the period if known (`Q3 2026`, `by 2026-12-31`); else `[period]`.
- One sentence. No stacking of multiple goals.

**Key Results (2–4)**

- Outcome, not activity: a result that would be true if the Objective were achieved.
- Metric + baseline + target: `from X to Y` (or `from X to Y by [date]`).
- Complementary: together they would mean the Objective is achieved — not four restatements of one number, and not a KR that is unrelated.
- Prefer leading/lagging mix only when both are outcomes (e.g. activation rate and retained revenue), never "ship the project" as a KR.

Rewrite output-shaped input ("launch the dashboard", "do 20 customer calls") into the outcome those activities were meant to produce. If that outcome is unknowable, ask the one clarifying question.

### Step 2 — Quality check every KR

Run an alignment/quality check on every Key Result against these criteria, and flag failures explicitly:

- Is it measurable with a clear number/metric (not vague like "improve" or "increase")?
- Is it an outcome (impact) rather than an output (a task or deliverable)?
- Is it realistically tied back to the stated Objective — would achieving all KRs actually mean the Objective was achieved?
- Is it something the team can meaningfully influence (not fully dependent on another team with no ownership)?
- Is there a clear baseline and target (from X to Y), not just a target?

Score each KR against all five. A KR **fails** if any criterion is No. Flag the failed criterion by name; do not hide a fail inside a pass.

Also flag at the **set** level if: fewer than 2 or more than 4 KRs; KRs that all measure the same thing; or achieving every KR would still leave the Objective unproven (coverage gap — name what is missing).

### Step 3 — Ladder-up (only if given both)

If given multiple team-level OKRs, check for alignment against a stated company-level Objective, and flag any KR that doesn't ladder up.

A KR ladders up if hitting it makes the company Objective more true (direct or a clear leading indicator). Flag: no causal path, opposes the company Objective, or is a local output that does not move the company result. Do not invent a company Objective. If team OKRs are given without a company Objective, skip this step.

## Output

A clean OKR block, followed by a short "Quality Check" section listing any issues found and a suggested fix for each.

```markdown
## Objective
[Time-bound qualitative objective]

## Key Results
1. [Metric] from [baseline] to [target] by [date]
2. ...

## Quality Check
**KR1 — [short label]:** PASS
**KR2 — [short label]:** FAIL — [criterion]
- Issue: [one line]
- Fix: [rewritten KR or the missing number/owner to add]

**Set:** [PASS, or coverage/ladder issue + fix]

**Company alignment:** [only if Step 3 ran]
- KR# does not ladder up — [why] — Fix: [rewrite or drop]
```

If every KR and the set pass, keep Quality Check to one line: `All KRs passed the five checks.` Still show the OKR block.

When rewriting a failed KR, put the suggested replacement in the Fix line. Do not silently swap it into the OKR block unless the user asked to apply fixes. Exception: Step 1 drafts should already try to pass; Quality Check is for leftovers and for user-supplied OKRs being validated.

## Modes

- **Draft** (default): rough goal → Objective + KRs + check.
- **Check-only:** user pastes existing OKRs → skip new drafting; run Steps 2–3 on what they wrote.
- **Align:** company Objective + team OKRs → Step 3 plus Step 2 on each KR.

## Guardrails

- Do not fabricate metrics, baselines, or industry benchmarks.
- Do not use vanity counts (tickets closed, PRs merged, meetings held, docs written) as KRs.
- Do not make the Objective a restatement of the KRs, or the KRs a restatement of the Objective with a number bolted on.
- Keep the Quality Check short: issue + fix, no lecture.

## Additional resources

- Worked examples: [examples.md](examples.md)
