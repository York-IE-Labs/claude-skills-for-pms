# Examples

Fictional product/team. Quality targets, not copy-paste output.

## 1. Draft from a rough goal

**Input:** "Checkout feels flaky. We want people to actually complete purchases this quarter."

**Draft:**

```markdown
## Objective
Make checkout a path customers finish with confidence in Q3 2026.

## Key Results
1. Checkout completion rate from [baseline]% to [target]% by 2026-09-30
2. Payment-error rate from [baseline]% to [target]% of checkout attempts by 2026-09-30
3. Repeat-purchase rate within 30 days among successful checkouts from [baseline]% to [target]% by 2026-09-30

## Quality Check
**KR1 — completion rate:** FAIL — baseline and target
- Issue: Metric is clear but [baseline] and [target] are unset.
- Fix: Replace with real rates (e.g. from last quarter's completion % to the Q3 goal).

**KR2 — payment errors:** FAIL — baseline and target
- Issue: Same — placeholders instead of from X to Y.
- Fix: Fill current payment-error % and the target %.

**KR3 — repeat purchase:** FAIL — baseline and target
- Issue: Placeholders; also confirm this team can influence repeat purchase (not only checkout reliability).
- Fix: Use a checkout-owned proxy if needed (e.g. "checkout sessions with zero error retries from X% to Y%").

**Set:** Coverage is right once numbers are filled — completion + errors would mean the Objective is largely true; drop KR3 if repeat purchase is owned by another team.
```

## 2. Check-only: output KR and vague wording

**Input OKRs:**
```
O: Be the best payments platform
KRs:
- Improve reliability
- Launch the new dashboard
- Increase NPS to 50
```

**Quality Check (excerpt):**

```markdown
## Quality Check
**KR1 — improve reliability:** FAIL — measurable
- Issue: "Improve" has no metric.
- Fix: Payment success rate from [baseline]% to [target]% by [date].

**KR2 — launch dashboard:** FAIL — outcome vs output
- Issue: A deliverable, not an impact. Shipping the dashboard does not prove the Objective.
- Fix: Time-to-first-successful-payout for new merchants from [baseline] to [target] (the outcome the dashboard was for).

**KR3 — NPS to 50:** FAIL — baseline and target; influence
- Issue: Target only (no from X); NPS is often lagging and partly owned by other teams.
- Fix: If this team owns checkout support contacts: checkout-related support tickets per 1k transactions from [baseline] to [target]. Add baseline next to 50 only if NPS is truly this team's outcome.

**Set:** FAIL — tied back to Objective
- Issue: Even hitting these would not mean "best payments platform" — Objective is not time-bound and KRs do not define "best."
- Fix: Rewrite Objective to a time-bound customer/business state, then 2–4 outcome KRs that would prove it.
```

## 3. Too vague — one question, no draft

**Input:** "Get better this year."

**Response (do not draft yet):**

> What should be different for customers or the business by end of year if this is a success?

## 4. Company alignment

**Company Objective:** Grow profitable self-serve revenue this year.

**Team KR that ladders:** Self-serve conversion from trial to paid from 8% to 12% by Q4.  
**Team KR that does not:** Publish 12 engineering blog posts by Q4.

```markdown
**Company alignment:**
- KR (blog posts) does not ladder up — activity with no stated path to profitable self-serve revenue.
- Fix: Drop, or replace with a self-serve outcome this team owns (e.g. activation rate from X% to Y% on the onboarding flow they run).
```

## Anti-examples (do not do this)

**Task Objective:** "Ship search v2 in Q3."  
**Vanity KR:** "Close 40 tickets." / "Hold 20 customer calls."  
**Guessed numbers:** filling 12% → 18% with no source in the input.  
**Several clarifying questions** before drafting when one would unblock.
