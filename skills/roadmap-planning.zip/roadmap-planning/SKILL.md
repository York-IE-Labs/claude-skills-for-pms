---
name: roadmap-planning
description: Build or restructure a product roadmap in whatever format best fits the audience — Now/Next/Later, quarterly timeline, or Gantt-style with dependencies. Use this whenever the user wants to plan, organize, prioritize, or visualize a product roadmap — whether starting from raw inputs (backlog items, requirements, epic hypotheses, feature requests) or restructuring an existing messy/informal roadmap. Trigger this even if the user doesn't say "roadmap" explicitly — phrases like "what should we build next," "help me sequence this work," "prioritize our backlog for the quarter," or "lay out our plan for the next few months" all call for this skill. Always use this for any request to produce a prioritized initiative view with timing, or a visual/markdown roadmap artifact.
---

## Purpose

Product roadmaps fail when they overcommit to dates that get punished later ("why did this slip?")
— but different audiences need different levels of precision. A steering committee often wants
directional confidence (Now/Next/Later); an exec sponsor may want quarters; an engineering-facing
plan may need dependencies and milestones. This skill asks which fits the situation rather than
assuming one:

- **Now/Next/Later** — theme-based, outcome-oriented, communicates confidence honestly (Now =
  committed, Next = planned but flexible, Later = directional/exploratory). Best default when the
  audience or precision level is unclear, since it avoids false calendar precision.
- **Quarterly timeline** — initiatives placed in Q1/Q2/Q3/Q4 (or H1/H2). Best when the audience
  (execs, clients) explicitly wants calendar-anchored planning.
- **Gantt-style** — initiatives with start/end estimates, dependencies, and milestones. Best for
  engineering-facing delivery planning where sequencing and blockers matter more than narrative.

Each item also carries a **target timeframe** (e.g. "Q1 2027," "H2," "TBD") as metadata regardless
of format, so switching formats later doesn't require re-gathering information.

This is not a full delivery schedule for already-committed work — once an item is scoped in detail,
see `scope-of-work` / `prd-development` if those skills are available.

---

## When to Use This

- User hands over a pile of backlog items, requirements, feature requests, or epic hypotheses and wants them organized into a roadmap
- User has an existing rough/messy roadmap (spreadsheet, list, prior doc) that needs restructuring, re-prioritizing, or cleaning up
- User asks to sequence, prioritize, or plan "what's next" for a product
- User wants a shareable roadmap view for stakeholders, in whatever format fits

## When NOT to Use This

- User wants a detailed delivery schedule with dependencies/dates for already-committed work → that's a project plan, not a roadmap
- User wants a single epic scoped in detail → use `scope-of-work` or `prd-development` instead
- User wants to validate whether an idea is worth building at all → use `epic-hypothesis` first, then bring the validated epic here

---

## Application

### Step 1: Determine the starting point

Figure out which situation you're in:

1. **From raw inputs** — user provides backlog items, requirements, feature requests, or epic hypotheses with no existing structure. You'll need to help them group and prioritize from scratch.
2. **Restructuring an existing roadmap** — user has something already (a list, spreadsheet, doc). Read/ingest it first, then re-organize.

If it's ambiguous, ask which situation applies — don't assume.

### Step 2: Ask which roadmap format to use

**Do not default to Now/Next/Later silently.** Ask the user which format fits, unless they've already told you in this conversation:

- **Now/Next/Later** — theme-based, confidence-driven, no hard dates required
- **Quarterly timeline** — items placed in Q1/Q2/Q3/Q4 or H1/H2
- **Gantt-style** — items with start/end estimates, dependencies, milestones

If the user says "you pick" or doesn't have a preference, default to **Now/Next/Later** — it's the safest choice when precision level/audience is unclear, since it avoids implying certainty the user doesn't have. Note that choice explicitly so they can redirect you.

Each format has its own rendering guidance in `references/formats.md` — read the relevant section for the format chosen before rendering in Step 6.

### Step 3: Gather the initiative list

For each initiative/item, try to capture:
- **Name** — short, descriptive title
- **Description** — one to two sentences on what it is and why it matters
- **Owner/team** (if known)
- **Target timeframe** (if known — quarter, half, or "TBD")
- **Dependencies or blockers** (if known)

If inputs are raw/unstructured (e.g. a KT transcript, a stream-of-consciousness list, epic hypotheses), extract and normalize into this shape yourself — don't just ask the user to reformat their own input.

### Step 4: Establish the prioritization framework

**Do not assume a framework.** Ask the user which of these they want to use, unless they've already told you in this conversation:

- **RICE** (Reach, Impact, Confidence, Effort) — best when you have or can estimate quantitative inputs
- **Value vs. Effort** (simple 2x2) — best for quick, qualitative sequencing with a small set of items
- **Theme-based** — group by strategic theme/OKR alignment with no numeric scoring; best when the goal is narrative alignment over precise ranking

Default recommendation if the user says "you pick": **Value vs. Effort** for fewer than ~10 items, **RICE** for larger backlogs with enough data to score reach/impact/confidence, **theme-based** when the ask is more about communicating strategy than ranking a big backlog.

### Step 5: Score/sort and sequence items

Apply the chosen prioritization framework:

- **RICE**: Score = (Reach × Impact × Confidence) / Effort. Rank descending. Note when you had to estimate a value the user didn't provide — flag it as an assumption.
- **Value vs. Effort**: Plot each item into High Value/Low Effort (do first), High Value/High Effort or Low Value/Low Effort (do next), Low Value/High Effort (later, or cut).
- **Theme-based**: Group items under 2–4 strategic themes; within each theme, order by the team's stated priority or by dependency logic (blockers first).

Then map the ranked/grouped items onto the chosen format's structure (buckets, quarters, or a sequenced timeline with dependencies) — see `references/formats.md` for how each format organizes items. Flag any placement that's a judgment call so the user can override it.

### Step 6: Capture timeframe metadata

For each item, attach a target timeframe where known or reasonably inferable. If the user hasn't given real dates, use relative labels (e.g. "H2," "TBD") rather than inventing specific quarters — don't manufacture false precision, regardless of format.

### Step 7: Render the roadmap artifact

Produce a markdown artifact (use the `create_file`/artifact workflow, not just inline text) using the template for the chosen format in `references/formats.md`.

Keep descriptions tight — this is a scanning document for stakeholders, not a spec. If the user wants more detail on a specific item, that's a signal to hand off to `scope-of-work` or `prd-development`, not to bloat the roadmap.

### Step 8: Sanity-check with the user

Before finalizing, surface:
- Any items you had to guess a placement, timeframe, or score for
- Any obvious imbalance (e.g. everything crammed into the near-term)
- Any dependency conflicts (an early item depends on something scheduled later)

---

## Common Pitfalls

### Pitfall 1: Treating Now/Next/Later like Q1/Q2/Q3
**Symptom:** Every "Now" item gets a hard date, every "Next" item gets a hard date.
**Fix:** Dates are optional metadata, not the organizing principle. The bucket communicates confidence; the date is a rough estimate at best.

### Pitfall 2: Skipping the prioritization framework or format conversation
**Symptom:** Jumping straight to Now/Next/Later (or any other format) without asking how the user wants to prioritize or which format fits their audience.
**Fix:** Always confirm the format (Step 2) and the prioritization framework (Step 4) first — different choices produce meaningfully different roadmaps, and silently picking Now/Next/Later for everyone defeats the point of asking.

### Pitfall 3: Overloading the near-term
**Symptom:** 15 items in Now (or Q1), 2 in Next (or Q2), 1 in Later.
**Fix:** Near-term should reflect actual capacity, not everyone's wish list. Push back and ask about team capacity if the near-term bucket looks bloated.

### Pitfall 4: Fabricating scores or dates
**Symptom:** Inventing a Reach/Impact/Confidence number or a specific quarter because the user didn't provide one.
**Fix:** Estimate only when reasonable, and always flag estimates explicitly rather than presenting them as given data.

---

## References

- `references/formats.md` — Rendering templates and placement guidance for each of the three formats (Now/Next/Later, Quarterly timeline, Gantt-style). Read the relevant section before Step 7.

---

**Skill type:** Standalone
**Suggested filename:** `roadmap-planning.md`
**Output:** In-chat markdown artifact (format chosen by user: Now/Next/Later, Quarterly timeline, or Gantt-style)
