# Roadmap Format Templates

Read only the section for the format the user chose in Step 2.

---

## Now/Next/Later

**Placement logic:**
- **Now**: top-ranked, scoped enough to start, no unresolved blockers
- **Next**: strong candidates, sequenced after Now, may still need scoping
- **Later**: lower-ranked, unscoped, exploratory, or dependent on Now/Next outcomes

**Template:**

```markdown
# [Product/Initiative] Roadmap
_Last updated: [date] · Prioritization method: [RICE / Value-Effort / Theme-based]_

## Now
### [Item Name] — [Target timeframe]
[1-2 sentence description]
**Owner:** [if known] · **Why now:** [1 line rationale]

## Next
### [Item Name] — [Target timeframe]
[1-2 sentence description]
**Owner:** [if known] · **Depends on:** [if any]

## Later
### [Item Name] — [Target timeframe or "Exploratory"]
[1-2 sentence description]
**Why later:** [1 line rationale — e.g. needs validation, blocked, lower priority]
```

---

## Quarterly Timeline

**Placement logic:** Assign each item to a quarter (or half) based on rank/priority and realistic
capacity per period. Don't spread items evenly just to fill quarters — leave a quarter light if
there isn't enough validated, prioritized work to fill it. Items without a confident date go in an
"Unscheduled / Exploratory" section rather than being forced into a quarter.

**Template:**

```markdown
# [Product/Initiative] Roadmap
_Last updated: [date] · Prioritization method: [RICE / Value-Effort / Theme-based]_

## Q1 [Year]
### [Item Name]
[1-2 sentence description]
**Owner:** [if known] · **Status:** [Committed / Planned]

## Q2 [Year]
### [Item Name]
[1-2 sentence description]
**Owner:** [if known] · **Status:** [Committed / Planned]

[... additional quarters as needed ...]

## Unscheduled / Exploratory
### [Item Name]
[1-2 sentence description]
**Why unscheduled:** [1 line rationale]
```

---

## Gantt-Style (dependencies & milestones)

**Placement logic:** Sequence items by dependency order first, then by priority within dependency
constraints. Every item should have an estimated start/end (even if rough — call out uncertainty
rather than omitting it) and explicit dependency links where they exist. Surface any circular or
conflicting dependencies immediately rather than rendering them silently.

**Template:**

```markdown
# [Product/Initiative] Roadmap
_Last updated: [date] · Prioritization method: [RICE / Value-Effort / Theme-based]_

## Timeline

| Item | Start | End | Depends On | Milestone |
|---|---|---|---|---|
| [Item Name] | [date/period] | [date/period] | [item name or "—"] | [key milestone, if any] |
| [Item Name] | [date/period] | [date/period] | [item name or "—"] | [key milestone, if any] |

## Item Details
### [Item Name]
[1-2 sentence description]
**Owner:** [if known] · **Depends on:** [if any] · **Blocks:** [if any]
```

For a visual (not just tabular) Gantt rendering, consider using the visualize/diagram tool if
available — a markdown table communicates the same information but a rendered timeline chart may
better serve stakeholder-facing decks. Ask the user which they'd prefer if it's not clear from
context.
