# PRD Examples

---

## Example 1: Real PRD — Production Ready Agent

**Why this works:**

- TL;DR leads with the current constraint (30 accounts), the goal (500), and the business reason (pipeline generation)
- Phase 1 / Phase 2 split makes scope explicit and prevents overbuilding
- Goals & Success numbers are concrete and testable
- Open Issues captures a real architectural decision rather than leaving it implicit

---

```markdown
# PRD: Production Ready Agent

**Contributors:** Lay Shah

**TL;DR:** Today, our agent can support workflows of 30 accounts. This severely limits our customers' ability to run large campaigns and deliver enough messaging volume to elicit the responses they need to meet pipeline generation goals. This work will allow customers to run more accounts within a workflow, and it will harden our system so we can support more customers.

**Status:** Product Definition & Solution Validation

**Shipping:**

---

## Problem Alignment

### The Problem

As a company, we made assumptions about the number of accounts a customer should target every month in order to achieve pipeline generation goals. We set that number too low. A sales rep targeting 10 accounts per month will rarely book a meeting — that is not the reality in practice. The best chance we have at helping customers hit their pipeline generation goals is to increase the number of accounts they are targeting every month while ensuring they adhere to outbound prospecting best practices.

Current state vs. proposed state:

|                         | Current                    | Proposed                    |
| ----------------------- | -------------------------- | --------------------------- |
| Accounts/rep/mo         | 10                         | 50                          |
| Contacts/account        | 6 (3 personas × 2)         | 10                          |
| Outputs/persona         | 9 (3 email, 3 phone, 3 LI) | 12 (6 email, 3 phone, 3 LI) |
| Total outputs           | 540                        | 6,000                       |
| Total replies (est.)    | 12.6                       | 120                         |
| Positive replies (est.) | 1.98                       | 21                          |

### High-level Approach

Phase 1: Scale

To onboard more customers to our web app, we need to ensure our agent workflow can support dozens of concurrent workflows and larger volumes of accounts (up to 500).

- Throttle workflows — implement API rate limiting and concurrency controls
- Allow customers to preview results — let customers validate results on first accounts before waiting hours for a full run
- Inform customers of duration remaining — set proper expectations for long-running workflows
- Disqualify accounts based on poor contact coverage — exit accounts early if we can't reach sufficient contacts, preventing wasted deep research spend

Phase 2: Improve Outputs (Out of Scope)

- Improved account prioritization with better ICP definitions (includes updates to Seller Profile)
- Allow for regeneration of messaging without re-running the entire research workflow

### Goals & Success

1. Support 100+ customers on the platform at a given time.
2. Increase the number of accounts that can be processed in a workflow from 30 (current) to 500.

---

## Solution Alignment

### Key Features

Phase 1

Scalable Agent Workflow — supporting more accounts and more customers concurrently

- More accounts & more customers — aim to reduce per-account processing time; if not possible, modify the UI to set duration expectations. Scale concurrent request handling so nothing breaks under load.
  - Investigate Anthropic rate limits
  - Investigate DiffBot rate limits

Improved UX — create campaign experience must set proper expectations

- Set proper expectations — customers should be informed campaigns may take several hours to process
- Allow customers to preview results — preview first accounts before continuing, so customers can course-correct without waiting hours

— Cut Line —

Phase 2 (out of scope)

Account Prioritization — Progressive Disqualification

- ICP firmographic scoring — evaluate accounts against ICP attributes using core data
- Contact coverage scoring — evaluate IBP fit of contacts in core data before committing to deep research

### Key Flows

Phase 1 (MVP):

- Customer creates campaign → system estimates duration and informs customer → agent begins processing accounts → customer can preview results after first accounts complete → customer confirms to continue full run

Phase 2:

- TBD — dependent on contact matching improvements

### Open Issues & Key Decisions

Is it easier to separate messaging regeneration from research (allow customers to regenerate messaging independently) OR let customers preview the results of the first account from a workflow before continuing on?
```

---

## Example 2: Real PRD — Contact Matching Improvements

**Why this works:**

- The Problem section names 5 distinct failure modes, each with a clear label — makes triage easy
- Goals & Success table ties each goal to a concrete metric and explains why the metric matters (the "Why It Matters" column does heavy lifting for stakeholder alignment)
- "What We're Not Building (Yet)" is a single, explicit line — no ambiguity

---

```markdown
# PRD: Contact Matching Improvements

**Contributors:** Nick Hart

**TL;DR:** We need to improve how we identify and match contacts to accounts, personas, and messaging workflows. This involves validating InstaDB's improvements to contact:account joins, upgrading the Contact Matching agent, potentially enriching Seller Profile personas, and increasing sourced contacts per account. We may also restructure the campaign/workflow agent process to disqualify accounts based on lacking contact coverage earlier in the process.

**Status:** Product Definition

**Shipping:**

---

## Problem Alignment

### The Problem

Our outbound success depends on having accurate, persona-aligned contacts tied to accounts. Today, several issues are affecting that reliability:

- **Unreliable contact:account joins** — Some contacts in our core data are not properly mapped to accounts, reducing sourcing accuracy.
- **Weak persona matching** — Our Contact Matching agent currently does basic title matching against a limited persona list in the Seller Profile.
- **Low contact volume** — We often return 3–5 contacts per account, even for large companies.
- **Late-stage contact discovery** — Contact sourcing currently occurs after research is run, which wastes compute and workflow time for accounts that should be disqualified due to poor contact coverage.
- **Poor contact data** — We often source contacts who have bad contact data. Where there is low-hanging fruit, we should catch bad data before sending it to customers.

### High-level Approach

1. **Implement InstaDB** — Work with InstaDB to join accounts and contacts, implement quality control scoring, and plug this into our contact-sourcing agent workflow.
2. **Enhance the Contact Matching agent** — Improve our ability to match contacts to ideal personas using more of our available data.
3. **Strengthen persona definitions (if needed)** — Expand Ideal Buyer Persona section in the Seller Profile with more options and structured fields.
4. **Reorder workflow logic** — Move contact sourcing earlier in the workflow so we can disqualify low-coverage accounts before running deep research.
5. **Implement data quality checks** — Evaluate the need for each phase based on result quality:
   - Data Verification from Data Providers (5x5, PDL have verification flags we're not using)
   - Data Verification via Verification Services (LeadMagic, Wiza, DeBounce)
   - Agent-based LinkedIn QA (confirm employment details and persona fit)

### Goals & Success

| Goal                             | Metric                                                 | Why It Matters                                      |
| -------------------------------- | ------------------------------------------------------ | --------------------------------------------------- |
| Improve contact:account coverage | # of contacts per account vs. before InstaDB           | Better joins ensure we're sourcing the right people |
| Increase persona match accuracy  | % of sourced contacts matching a defined persona       | Higher relevance improves messaging quality         |
| Raise contact count per account  | Median contacts/account ≥ 6                            | Increases message volume and sequence throughput    |
| Reduce invalid contacts          | % of contacts with verified deliverable emails         | Better deliverability and trust in system data      |
| Reduce wasted workflows          | Reduced average cost per account initiated in workflow | Saves compute cost and user time                    |

---

## Solution Alignment

### Key Features

1. **InstaDB Integration**
   - Implement InstaDB join logic to enrich contact:account relationships
   - Implement quality control scoring so only the best contacts are suggested
   - Plug this into our contact-sourcing agent workflow

2. **Contact Matching Agent Enhancements**
   - Improve ability to match contacts to ideal personas using more available data
   - Run tests on current agent workflow to determine better matching approaches

3. **Improve Persona Definitions in Seller Profile (if needed)**
   - Increase the number of Personas in Seller Profile
   - Expand Persona definitions to focus more on Jobs-to-be-done instead of just title, department, and seniority

4. **Value Scenario and/or Messaging Agent Enhancements (if needed)**
   - If we increase the number of Personas, update the Value Scenario step to either pick the 3 best coverage personas or allow more than 3 personas through the workflow

5. **Workflow Reordering**
   - Move contact sourcing to the beginning of the workflow
   - Disqualify accounts with no viable contacts before research & messaging
   - Provide an output report explaining why the account was disqualified

6. **Contact Data Quality Checks**
   - Use 5x5/PDL Verification Flags — implement filtering for known bad emails or low-quality signals
   - Integrate LeadMagic or equivalent — run all emails through an external verification API; disqualify contacts with invalid emails
   - Agent-Based LinkedIn QA — scrape LinkedIn to confirm employment and job relevance

### What We're Not Building (Yet)

- **Bring-your-own-Data** — We plan to do this in the future but will not let customers import or integrate their own contact data in this release.

### Key Flows

- TBD

### Open Issues & Key Decisions

[None documented at time of writing]
```

---

## Example 3: Real PRD — Messages Created for Sequences

**Why this works:**

- High-level Approach immediately clarifies scope boundary ("we are NOT building a sequence engine")
- Goals & Success table includes "Why It Matters" column — forces the PM to connect metrics to business outcomes, not just vanity numbers
- Messaging Strategy Object table makes the output format unambiguous for engineers
- Two-phase Key Flows (MVP vs. customer-configurable) make the rollout plan clear without overcommitting

---

```markdown
# PRD: Messages Created for Sequences

**Contributors:** Nick Hart

**TL;DR:** Today, Operator generates 3 standalone emails per account, each intended as a first touch. Customers often use these as sequences, which leads to redundant or repetitive messaging. We will instead generate a full 6-message sequence per account that progresses logically and builds off prior messages. This will improve buyer experience and increase reply rates. We'll also update downstream outputs to support these longer sequences.

**Status:** Product Definition & Solution Validation

**Shipping:**

---

## Problem Alignment

### The Problem

Operator's current messaging generation agent produces 3 email messages, 3 LinkedIn Messages, and 3 Phone Scripts per account — each designed to stand alone as a single, initial email. However, these messages are often used in sequence, which creates friction:

- **Redundancy** — The buyer receives multiple messages that restate the same points.
- **Missed opportunity** — We don't tell a story or evolve our pitch across touches.
- **Manual work** — Customers have to manually rewrite messages to make them work in a sequence.

We are **not** aiming to build a full sequence engine or orchestration tool. This project is focused solely on message generation that can be plugged into existing tools like HubSpot Sequences (and Outreach, Salesloft, or similar in the future).

### High-level Approach

Update Operator's message generation agent to produce **6 emails, 3 LinkedIn Messages, and 3 Call Scripts that are sequentially aware** per account. These messages will:

- Reference or imply prior messages to avoid repetition
- Progress through different value propositions
- Use varied tones and CTAs across the sequence
- Be exported via the same mechanisms as today

Build this in a way that allows for flexibility of messaging output structure and step count. In the future, we want to support multiple formats of messaging output, so we should build a framework that allows for this flexibility.

### Goals & Success

| Goal                          | Metric                                                      | Why It Matters                                                |
| ----------------------------- | ----------------------------------------------------------- | ------------------------------------------------------------- |
| Increase messaging reply rate | % lift in replies across customers using sequences          | Reply rate is the north-star metric for message effectiveness |
| Improve recipient experience  | Reduction in complaints or opt-outs when sequencing is used | Ensures messaging is non-repetitive and respectful            |
| Reduce manual rewriting       | % of users using full sequences without editing             | Indicates customers trust the messaging to flow naturally     |
| Extend platform value         | More customers use Operator messaging directly in SEPs      | Drives stickiness and workflow integration                    |

---

## Solution Alignment

### Key Features

1. **12-Step Sequence Generation**
   - Each message is designed for a specific position in the sequence (e.g. Email 1: Education, Email 2: Attaching observed Pain to a Solution, Email 3: Asking for a meeting)
   - The agent understands prior messages and avoids repetition
   - Variable CTAs and subject lines
   - Additional inputs allow for variation through the steps

2. **Sequence structure based on a modifiable template**
   - The steps in the sequence are determined by a template that can be easily changed in the future
   - We should not have to build a full new prompt for each new structure we want to support

3. **Current Writing Styles (Messaging Controls) impact the output**
   - The customer should still be able to use the current messaging controls settings to modify output

4. **Support for LinkedIn Invitation Messages**
   - Since most LinkedIn messages must start with a connection request, we need to support LinkedIn Invitation Messages as well as standard LinkedIn messages

5. **Support for Reply Steps and New Threads**
   - Some emails stand alone as a single message (with a Subject Line); some messages are designed to be sent as a reply to a previously sent message

6. **Messaging Strategy Object**
   - An object that represents the structure of the output the customer wants — sequence steps, types of steps, order of steps, and any instructions for generating the messaging

**Messaging Strategy Object — Default 12-Step Structure:**

| Step #  | Channel — Detail                |
| ------- | ------------------------------- |
| Step 1  | Email (New Thread) — First      |
| Step 2  | LinkedIn — Connection Request   |
| Step 3  | Phone — Call Script             |
| Step 4  | Email (Reply) — Reply to Step 1 |
| Step 5  | Email (New Thread) — Second     |
| Step 6  | Phone — Call Script             |
| Step 7  | LinkedIn — InMail Message       |
| Step 8  | Email (Reply) — Reply to Step 5 |
| Step 9  | Email (New Thread) — Third      |
| Step 10 | Phone — Call Script             |
| Step 11 | LinkedIn — InMail Message       |
| Step 12 | Email (Reply) — Reply to Step 9 |

### Key Flows

Phase 1 (MVP): No customer UI experience

- Customer runs an Operator Campaign → system applies a Messaging Strategy to the Campaign → output is generated in the defined sequence format

Phase 2: Customer-configurable Messaging Strategy object in app

- Customers can configure their own Messaging Strategies in Operator so they can control the output structure from the system, aligning it with their Sequences

### Open Issues & Key Decisions

[Keep track of open issues / key decisions here. Document controversial decisions so people know that discussions have happened and there's strong awareness of the tradeoffs.]
```

---

## Anti-Pattern: The Feature List PRD

**Why this fails:**

```markdown
# Onboarding PRD

**Problem:** Users want better onboarding.

**Solution:** Add onboarding.

**Requirements:**

1. Onboarding flow
2. Tooltips
3. Help docs
```

- No TL;DR — what is the current state? What are we changing?
- No evidence — who wants this? What data shows the problem?
- No Goals & Success — how do we know when "better" is achieved?
- No Key Features — what does "onboarding flow" actually mean to build?
- No Key Flows — what does the customer/user actually experience?
- No What We're Not Building — scope will expand without this

**Fix:** Use the Problem Alignment / Solution Alignment structure above. Start with the TL;DR — it forces you to articulate the current state and the specific change you're making.
