# PRD Template

Use this template to produce a structured Product Requirements Document aligned to the YORKIE PRD format.

## Template

```markdown
# PRD: [Feature Name]

**Contributors:** [Name(s)]

**TL;DR:** [1–2 sentences: current state → what we're building → why it matters and what it will achieve]

**Status:** [Product Definition | Solution Validation | In Development | Shipped]

**Shipping:** [Target date or TBD]

---

## Problem Alignment

### The Problem

[Narrative paragraph describing the core problem. Follow with bullet points for specific pain points, root causes, or downstream consequences.]

- [Pain point 1]
- [Pain point 2]
- [Pain point 3]

### High-level Approach

Phase 1: [Phase label — e.g., "Scale," "MVP," "Core Feature"]

[Brief framing sentence for what Phase 1 addresses.]

- [Approach bullet 1]
- [Approach bullet 2]
- [Approach bullet 3]

Phase 2: [Phase label or "Out of Scope"]

- [Out of scope item 1 — briefly explain why it's deferred]
- [Out of scope item 2]

### Goals & Success

| Goal     | Metric              | Why It Matters                   |
| -------- | ------------------- | -------------------------------- |
| [Goal 1] | [Measurable metric] | [Why this metric proves success] |
| [Goal 2] | [Measurable metric] | [Why this metric proves success] |
| [Goal 3] | [Measurable metric] | [Why this metric proves success] |

---

## Solution Alignment

### Key Features

Phase 1

[Feature Group Name]

- [Feature detail]
- [Feature detail]

[Feature Group Name]

- [Feature detail]
- [Feature detail]

— Cut Line —

Phase 2 (out of scope)

[Feature Group Name]

- [Feature detail]

### What We're Not Building (Yet)

- [Explicit exclusion 1 — and why]
- [Explicit exclusion 2 — and why]

### Dependencies & Risks

| Dependency / Risk    | Owner         | Notes                  |
| -------------------- | ------------- | ---------------------- |
| [Dependency or risk] | [Team/Person] | [Mitigation or status] |

### Key Flows

Phase 1 (MVP):

- [Flow description — who does what, trigger → action → outcome]

Phase 2:

- [Flow description]

### Open Issues & Key Decisions

[Unresolved question or decision that needs alignment before build begins]

[Another open question — include why it matters and who needs to decide]
```
