---
name: prd-development
description: Build a structured PRD using the Problem Alignment / Solution Alignment format. Use when turning discovery notes or client requirements into an engineering-ready document for a B2B SaaS initiative.
intent: >-
  Guide product managers through structured PRD creation using the two-section Problem Alignment / Solution Alignment format. Produces a TL;DR-first document that aligns stakeholders on why we're building something, what success looks like, what we're building, and what's explicitly out of scope — without over-specifying design or implementation.
type: workflow
theme: pm-artifacts
best_for:
  - "Writing a complete PRD from scratch for a B2B SaaS feature"
  - "Structuring product requirements before engineering handoff"
  - "Documenting a major initiative with clear phase boundaries"
  - "Producing a PRD a client PM team can review and act on"
scenarios:
  - "I need a PRD for scaling our agent workflow to support 500 accounts"
  - "I've completed a discovery sprint and need to turn the findings into a PRD my engineers can act on"
  - "Write a PRD for improving contact matching in our outbound platform"
estimated_time: "60-120 min"
---


## Purpose

Guide product managers through structured PRD creation using the **Problem Alignment / Solution Alignment** format. This produces a TL;DR-first document that answers:

1. **What is broken today and why does it matter?** (Problem Alignment)
2. **What are we building to fix it, and how do we know it worked?** (Solution Alignment)

This format is battle-tested in fast-moving B2B SaaS product teams. It is concise enough for executives to skim (TL;DR + Goals & Success), detailed enough for engineers to build from (Key Features + Key Flows), and honest enough to prevent scope creep (What We're Not Building).

This is not a waterfall spec — it's a working document that evolves as you learn through delivery.

## Key Concepts

### What is a PRD?

A PRD (Product Requirements Document) answers:

1. **What is the current state and why is it a problem?**
2. **What are we building to fix it?**
3. **How will we measure success?**
4. **What is explicitly out of scope?**
5. **What decisions are still open?**

### PRD Structure

```markdown
# PRD: [Feature Name]

Contributors: [Name(s)]
TL;DR: [1–2 sentences: current state → what we're building → why it matters]
Status: [Product Definition | Solution Validation | In Development | Shipped]
Shipping: [Target date or TBD]

---

## Problem Alignment

### The Problem
[Narrative + bullet points for specific pain points]

### High-level Approach
Phase 1: [Label]
- [Approach bullet]
Phase 2: [Label or "Out of Scope"]
- [Deferred item]

### Goals & Success
| Goal | Metric | Why It Matters |
|---|---|---|
| [Goal] | [Metric] | [Why] |

---

## Solution Alignment

### Key Features
[Numbered list of features with sub-bullets, organized by phase]

### What We're Not Building (Yet)
[Explicit exclusions]

### Dependencies & Risks
| Dependency / Risk | Owner | Notes |

### Key Flows
Phase 1 (MVP): [trigger → action → outcome]
Phase 2: [future flow]

### Open Issues & Key Decisions
[Unresolved questions that need alignment before build]
```

### Why This Works
- **TL;DR first** — any stakeholder can understand the initiative in 2 sentences
- **Problem before solution** — forces the team to align on the "why" before committing to "what"
- **Goals & Success table** — the "Why It Matters" column connects metrics to business outcomes
- **What We're Not Building** — prevents scope creep by making exclusions explicit
- **Phase structure** — separates MVP from future work without losing the roadmap context
- **Open Issues & Key Decisions** — serves as a living decision log for async teams

### Anti-Patterns (What This Is NOT)
- **Not a feature list** — "Add onboarding" is not a PRD; the problem, goal, and approach must all be present
- **Not a detailed spec** — PRDs frame the problem and solution at the right level; they don't specify UI pixel-by-pixel
- **Not waterfall** — PRDs evolve as you learn; they're not frozen contracts
- **Not a substitute for collaboration** — PRDs complement conversation, they don't replace it

### When to Use This
- Starting a major feature or product initiative
- Aligning cross-functional teams on scope, approach, and success criteria
- Documenting decisions for future reference
- Producing client-facing product documents at York IE

### When NOT to Use This
- For small bug fixes or trivial features (overkill — write a ticket instead)
- When problem and solution are already clear and aligned (just write user stories)
- For continuous discovery experiments (use a Lean UX Canvas instead)

---

### Facilitation Source of Truth

When running this workflow as a guided conversation, use [`workshop-facilitation`](../workshop-facilitation/SKILL.md) as the interaction protocol.

It defines:
- session heads-up + entry mode (Guided, Context dump, Best guess)
- one-question turns with plain-language prompts
- progress labels (for example, Context Qx/4 and Scoring Qx/3)
- interruption handling and pause/resume behavior
- numbered recommendations at decision points
- quick-select numbered response options for regular questions (include `Other (specify)` when useful)

This file defines the workflow sequence and domain-specific outputs. If there is a conflict, follow this file's workflow logic.

## Application

Use `template.md` for the full fill-in structure. See `examples/sample.md` for 3 complete real-world PRD examples.

This workflow orchestrates **4 phases** over **1–2 days**.

---

## Phase 1: Header & TL;DR (15 minutes)

**Goal:** Lock in the one-sentence summary that frames everything else.

### Activities

**1. Draft TL;DR**

Format: "Today, [current state / limitation]. This [work/feature] will [what we're building], [which/so that] [business or customer outcome]."

Example (Production Ready Agent):
> "Today, our agent can support workflows of 30 accounts. This work will allow customers to run more accounts within a workflow, and it will harden our system so we can support more customers."

Example (Messages for Sequences):
> "Today, Operator generates 3 standalone emails per account, each intended as a first touch. We will instead generate a full 6-message sequence per account that progresses logically and builds off prior messages, improving buyer experience and increasing reply rates."

**2. Set Status and Contributors**
- Status options: `Product Definition` → `Solution Validation` → `In Development` → `Shipped`
- Contributors: PM who owns the document (add design/eng leads as co-authors when relevant)

**Tip:** Write TL;DR first to force clarity, but refine it last after Problem Alignment and Solution Alignment are complete.

### Outputs from Phase 1
- TL;DR (1–2 sentences)
- Status, contributors, shipping date (or TBD)

---

## Phase 2: Problem Alignment (45–60 minutes)

**Goal:** Align the team on the "why" — what's broken, how we're approaching it at a high level, and what success looks like.

### Activities

**1. Write The Problem**

Lead with a narrative paragraph describing the root cause. Then break out specific pain points as bullets. Each bullet should be labeled (bold) and explained.

Example (Contact Matching Improvements):
```markdown
### The Problem

Our outbound success depends on having accurate, persona-aligned contacts tied to accounts. Today, several issues are affecting that reliability:

- **Unreliable contact:account joins** — Some contacts in our core data are not properly mapped to accounts, reducing sourcing accuracy.
- **Weak persona matching** — Our Contact Matching agent currently does basic title matching against a limited persona list in the Seller Profile.
- **Low contact volume** — We often return 3–5 contacts per account, even for large companies.
- **Late-stage contact discovery** — Contact sourcing currently occurs after research is run, which wastes compute and workflow time.
- **Poor contact data** — We often source contacts who have bad contact data.
```

**2. Write High-level Approach**

Define Phase 1 (what we're building) and Phase 2 (what's deferred). Use phase labels that describe the intent, not just numbers.

- Phase 1 label examples: "Scale," "MVP," "Core Feature," "Data Quality"
- Phase 2 label: use "Out of Scope" if nothing is planned yet, or name the next initiative

**3. Write Goals & Success**

Use a 3-column table: Goal | Metric | Why It Matters. Aim for 3–5 rows. The "Why It Matters" column must explain the business reason, not restate the metric.

Example (Contact Matching Improvements):
```markdown
| Goal | Metric | Why It Matters |
|---|---|---|
| Improve contact:account coverage | # of contacts per account vs. before InstaDB | Better joins ensure we're sourcing the right people |
| Raise contact count per account | Median contacts/account ≥ 6 | Increases message volume and sequence throughput |
| Reduce invalid contacts | % of contacts with verified deliverable emails | Better deliverability and trust in system data |
```

### Outputs from Phase 2
- The Problem (narrative + bullets)
- High-level Approach (Phase 1 scope + Phase 2 deferrals)
- Goals & Success (table with Goal, Metric, Why It Matters)

---

## Phase 3: Solution Alignment (60–90 minutes)

**Goal:** Define what we're building in enough detail for engineers to scope and design to begin — without specifying implementation.

### Activities

**1. Write Key Features**

Number each feature group. Use sub-bullets for specifics. Organize by phase (Phase 1 above the cut line, Phase 2 below).

Keep features at the "what," not the "how." Wrong: "Use PostgreSQL to store contact joins." Right: "Implement InstaDB join logic to enrich contact:account relationships."

Example format:
```markdown
### Key Features

Phase 1

1. **InstaDB Integration**
   - Implement InstaDB join logic to enrich contact:account relationships
   - Implement quality control scoring so only the best contacts are suggested
   - Plug into our contact-sourcing agent workflow

2. **Contact Matching Agent Enhancements**
   - Improve ability to match contacts to ideal personas using more available data
   - Run tests on current agent workflow to determine better matching approaches

— Cut Line —

Phase 2 (out of scope)

3. **Bring-your-own-Data** — Future capability; not in this release
```

**2. Write What We're Not Building (Yet)**

List features that were considered and explicitly deferred. The word "Yet" signals that exclusions are strategic, not permanent. Include a brief reason for each.

**3. Document Dependencies & Risks**

Use a table. Include technical dependencies, external vendor dependencies, and key risks. Name an owner for each.

**4. Write Key Flows**

Describe what the customer or user actually experiences, not the system internals. Use the Phase 1 / Phase 2 structure. If flows are complex, use numbered steps.

Example (Production Ready Agent):
```markdown
### Key Flows

Phase 1 (MVP):
- Customer creates campaign → system estimates duration and informs customer → agent begins processing accounts → customer can preview results after first accounts complete → customer confirms to continue full run

Phase 2:
- TBD — dependent on contact matching improvements
```

**5. Write Open Issues & Key Decisions**

List unresolved decisions that must be made before or during build. Frame each as a question. If a decision has been made but was controversial, document the decision and the reasoning.

Example (Production Ready Agent):
```markdown
### Open Issues & Key Decisions

Is it easier to separate messaging regeneration from research (allow customers to regenerate messaging independently) OR let customers preview the results of the first account from a workflow before continuing on?
```

### Outputs from Phase 3
- Key Features (organized by phase)
- What We're Not Building (Yet)
- Dependencies & Risks
- Key Flows
- Open Issues & Key Decisions

---

## Phase 4: Review & Finalize (30 minutes)

**Goal:** Polish the document and confirm the TL;DR still matches the body.

### Activities

**1. Reread TL;DR against body**
- Does the TL;DR still accurately describe what's in Problem Alignment and Solution Alignment?
- Update TL;DR if the scope changed during writing.

**2. Check Goals & Success**
- Are all metrics measurable with data you can actually access?
- Does each "Why It Matters" connect to a business outcome (not just restate the metric)?

**3. Check What We're Not Building**
- Is everything that was discussed but excluded listed here?

**4. Confirm Open Issues**
- Are all open decisions listed?
- Who needs to make each decision before build begins?

**5. Share for stakeholder review**
- Send to engineering lead, design, and relevant stakeholders before finalizing

### Outputs from Phase 4
- Finalized PRD ready for engineering handoff
- Decision on who resolves each Open Issue and by when

---

## Complete Workflow: End-to-End Summary

```
Day 1:
├─ Phase 1: Header & TL;DR (15 min)
├─ Phase 2: Problem Alignment (45–60 min)
│  ├─ The Problem
│  ├─ High-level Approach
│  └─ Goals & Success
└─ Phase 3: Solution Alignment (60–90 min)
   ├─ Key Features
   ├─ What We're Not Building (Yet)
   ├─ Dependencies & Risks
   ├─ Key Flows
   └─ Open Issues & Key Decisions

Day 2 (optional):
└─ Phase 4: Review & Finalize (30 min)
   └─ Stakeholder review & approval
```

**Total Time Investment:**
- **Fast track:** Half day (clear requirements, single phase)
- **Typical:** 1 day (includes discovery synthesis, stakeholder review)
- **Complex:** 1–2 days (major initiative, multiple phases, open architecture decisions)

---

## Common Pitfalls

### Pitfall 1: TL;DR that doesn't describe a change
**Symptom:** "We're improving contact matching."

**Consequence:** Stakeholders can't understand what's different about the world after this ships.

**Fix:** Lead with current state → change → outcome. "Today, we return 3–5 contacts per account. This work will raise median contacts per account to 6+ by improving our InstaDB join logic and upgrading the Contact Matching agent."

---

### Pitfall 2: Goals & Success without "Why It Matters"
**Symptom:** Metric list with no business context — "increase contacts per account," "reduce invalid contacts."

**Consequence:** Team doesn't understand which metrics to prioritize; executives can't assess business impact.

**Fix:** Always write the third column. "Increases message volume and sequence throughput" tells the team why ≥6 contacts matters more than ≥4.

---

### Pitfall 3: No "What We're Not Building (Yet)"
**Symptom:** PRD only describes what's in scope.

**Consequence:** Stakeholders assume discussed-but-deferred features are included; scope expands informally during build.

**Fix:** Every PRD should have this section. If nothing was explicitly deferred, write it anyway and add "No features are explicitly excluded from Phase 1." This signals the decision was made consciously.

---

### Pitfall 4: Key Features specify implementation, not capability
**Symptom:** "Use a rules-based scoring model with PostgreSQL to assign ICP fit scores using attribute weighting."

**Consequence:** Removes engineering judgment; becomes a waterfall spec.

**Fix:** "Score accounts based on ICP fit using the output from Light Research, so low-fit accounts can be disqualified before Deep Research." What, not how.

---

### Pitfall 5: Open Issues left unowned
**Symptom:** Open Issues section lists questions but no owner or deadline.

**Consequence:** Decisions don't get made; build starts with unresolved ambiguity.

**Fix:** For each open issue, note who makes the decision and when it's needed before engineering can proceed.

---

## References

### Related Skills (Used Within This Workflow)

**Problem Alignment:**
- `skills/proto-persona/SKILL.md` — if buyer/user persona needs formal documentation
- `skills/tam-sam-som-calculator/SKILL.md` — if market sizing is needed for Goals & Success
- `skills/discovery-interview-prep/SKILL.md` — if additional discovery is needed to write The Problem

**Solution Alignment:**
- `skills/epic-breakdown-advisor/SKILL.md` — if Key Flows need to be broken into user stories
- `skills/user-story/SKILL.md` — if acceptance criteria are needed for individual stories

### Real-World PRD Examples

See `examples/sample.md` for 3 complete real-world PRDs from Operator (B2B SaaS outbound sales automation):

1. **Production Ready Agent** — Scaling workflow from 30 → 500 accounts with throttling, previews, and duration estimates
2. **Contact Matching Improvements** — Improving persona-aligned contact sourcing via InstaDB, agent upgrades, and data quality checks
3. **Messages Created for Sequences** — Replacing 3 standalone emails with a 12-step sequentially-aware messaging framework

### External Frameworks
- Marty Cagan, *Inspired* (2017) — Product spec principles
- Amazon, "Working Backwards" (PR/FAQ format) — Alternative TL;DR-first approach
- Nick Hart, Operator PRDs (2025) — Source of the Problem Alignment / Solution Alignment structure used in this skill

---

**Skill type:** Workflow
**Suggested filename:** `prd-development.md`
**Suggested placement:** `/skills/workflows/`
**Dependencies:** Optionally orchestrates proto-persona, tam-sam-som-calculator, epic-breakdown-advisor, user-story
