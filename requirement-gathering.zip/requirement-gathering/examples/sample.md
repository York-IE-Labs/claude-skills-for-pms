# Requirements Document — Analytics Dashboard v1

**Client:** Acme Corp (B2B SaaS, project management tool)
**Date:** 2026-04-03
**PM:** York IE PM
**Status:** In Review

---

## Project Context

Acme Corp is building an analytics dashboard for their project management SaaS. Their mid-market customers (100-500 seat companies) are churning because they can't show ROI to executives. The dashboard needs to surface productivity and cost-savings metrics that customers can screenshot and share upward. Success means reducing churn in the 100-500 seat segment by 15% within 6 months of launch.

---

## Requirements

### Client / Stakeholder Requirements

| # | Requirement | Type | Priority | Status |
|---|---|---|---|---|
| C1 | Display team productivity metrics (tasks completed, velocity, on-time %) per user and per team | Functional | P1 | Clear |
| C2 | Allow date range filtering (last 7 days, 30 days, 90 days, custom) | Functional | P1 | Clear |
| C3 | Export dashboard as PDF or CSV for executive sharing | Functional | P1 | Clear |
| C4 | Show cost-savings estimate based on time saved vs. baseline | Functional | P2 | Needs Clarification |
| C5 | Support for multiple workspace views (per project, per team, per org) | Functional | P2 | Clear |
| C6 | Dashboard loads in under 3 seconds | Non-Functional | P1 | Clear |

**Open questions from client:**
- [ ] C4: How should "cost savings" be calculated — fixed hourly rate the customer sets, or an Acme-defined benchmark?

---

### Engineering / Design Requirements

| # | Requirement | Type | Priority | Status |
|---|---|---|---|---|
| E1 | Data must be pre-aggregated — no real-time queries against the transactions table at dashboard load | Non-Functional | P1 | Clear |
| E2 | Dashboard components must reuse the existing Recharts library (no new charting libraries) | Non-Functional | P1 | Clear |
| E3 | PDF export will use a headless Chrome screenshot approach — exact pixel fidelity not guaranteed | Non-Functional | P2 | Clear |
| E4 | Custom date ranges limited to max 1 year lookback (data warehouse retention limit) | Non-Functional | P1 | Clear |

**Open questions from engineering/design:**
- [ ] Design: Should the dashboard be a new page or embedded in the existing project view? Affects nav structure.

---

### Leadership / Executive Requirements

| # | Requirement | Type | Priority | Status |
|---|---|---|---|---|
| L1 | V1 must ship before Q3 renewal cycle (June 30 hard deadline) | Non-Functional | P1 | Clear |
| L2 | No third-party analytics SDKs — legal has flagged data residency concerns | Non-Functional | P1 | Clear |
| L3 | Must support SOC 2 audit trail — all dashboard views logged with user ID and timestamp | Non-Functional | P1 | Clear |

---

## Conflicts

| Conflict | Source A | Source B | Resolution |
|---|---|---|---|
| Real-time vs. pre-aggregated data | C6: loads in <3s (implies real-time feel) | E1: pre-aggregated only | Pre-aggregation with a "Last updated: X minutes ago" indicator — client agreed |
| Export fidelity | C3: export as PDF (implies polished) | E3: headless Chrome screenshot (imperfect fidelity) | Resolved — client accepted screenshot approach for V1 |

---

## Gaps

- [ ] No requirement covers empty state behavior (new customers with <7 days of data). Engineering and design need to define this.
- [ ] No requirement covers mobile responsiveness. Client didn't mention it — confirm if out of scope for V1.

---

## Priority Summary

**P1 — Must Have:**
C1, C2, C3, C6, E1, E2, E4, L1, L2, L3

**P2 — Should Have:**
C4, C5, E3

**P3 — Nice to Have:**
(none identified in this session)

---

## Next Steps

- [ ] Resolve C4: confirm cost-savings calculation method with client (owner: PM, by April 10)
- [ ] Resolve design question: new page vs. embedded (owner: design, by April 7)
- [ ] Confirm mobile out of scope for V1 (owner: PM, by April 7)
- [ ] Run `/york-ie:scope Analytics Dashboard v1` to create Scope of Work
