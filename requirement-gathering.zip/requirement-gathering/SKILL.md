---
name: requirement-gathering
description: Structure requirements from three sources — client stakeholders, internal engineering/design, and leadership. Use when capturing what needs to be built before scoping or writing a PRD.
intent: >-
  Guide York IE PMs through structured requirement gathering from three distinct sources: client/external stakeholders, internal engineering and design teams, and leadership/executives. Produces a requirements document where every requirement is tagged by source, assigned a priority, and marked as clear or needing clarification. Use this before creating a Scope of Work or PRD to ensure nothing critical is missed and conflicts are surfaced early.
type: workflow
theme: requirements
best_for:
  - "Capturing requirements from a client kickoff or discovery meeting"
  - "Consolidating inputs from multiple stakeholders before scoping"
  - "Identifying conflicting requirements before they become scope creep"
scenarios:
  - "I just had a kickoff call with the client — help me structure what came out of it"
  - "Engineering has constraints the client doesn't know about — how do I capture both?"
  - "I have notes from three different stakeholder meetings — help me consolidate into requirements"
estimated_time: "20-40 min"
---

## Purpose

Requirements without source attribution are requirements without accountability. This skill structures requirement gathering across three sources — client/stakeholder, engineering/design, and leadership/execs — so every requirement has an owner, a priority, and a clear status before scoping begins.

The goal is not a comprehensive wish list. It is a structured, conflict-surfaced, priority-tagged requirements document that can drive a Scope of Work and PRD.

## Key Concepts

### The Three Sources

Every York IE engagement produces requirements from three distinct voices. Capture all three — missing any source produces an incomplete picture.

**Source 1: Client / External Stakeholders**
Business goals, user needs, feature requests, and constraints from the client's team (founders, product owners, domain experts). These represent *what the client wants and why*.
- Weight: high on business outcomes, may be vague on technical feasibility
- Bias to watch: "We want X" without knowing if X is the right solution

**Source 2: Internal Engineering / Design**
Technical constraints, architecture limits, UX considerations, and implementation feasibility from the team building the product. These represent *what can be built and how*.
- Weight: high on feasibility and technical accuracy, may underweight business context
- Bias to watch: "That's technically difficult" as a substitute for "that's not worth prioritizing"

**Source 3: Leadership / Executives**
Strategic priorities, deadlines, non-negotiables, and resource constraints from York IE or client leadership. These represent *what must happen for the engagement to succeed*.
- Weight: high on strategic direction, may override both of the above
- Bias to watch: executive requests added late that override earlier agreement

### Requirement Anatomy

Each requirement should have:
- **Description** — what it is, in plain language
- **Source** — which of the three sources it came from
- **Priority** — P1 (must have), P2 (should have), P3 (nice to have)
- **Type** — functional (what the system does) or non-functional (performance, security, compliance)
- **Status** — Clear / Needs Clarification / Conflicted

### Conflicts and Gaps

A requirement is **conflicted** when two sources say contradictory things (e.g., client wants feature X, engineering says X is infeasible in the timeline). Surfacing these early prevents scope creep and broken promises.

A requirement is **a gap** when one source implies something the others haven't addressed (e.g., leadership sets a hard launch date but the feature list implies 2x more work than the date allows).

## Application

### Step 1: Set the context

Before capturing requirements, establish:
- What is the project? (one sentence)
- Who are the three sources for this engagement? (names/roles if known)
- Is there a Zoom transcript or meeting notes to process? If yes → run `transcript-processor` first, then use its output here.

### Step 2: Gather from each source

Work through each source systematically. For each, ask:

**Client / Stakeholders:**
- What problem are you trying to solve?
- What does success look like in 6 months?
- What features are non-negotiable?
- What are your biggest constraints (timeline, budget, integrations)?
- Who are the end users and what do they need most?

**Engineering / Design:**
- What technical constraints exist? (existing architecture, performance limits, third-party dependencies)
- What's feasible in the proposed timeline?
- What would need to be rebuilt or rearchitected?
- What are the integration points and risks?
- Are there UX patterns or design systems already in place?

**Leadership / Execs:**
- What are the strategic priorities for this engagement?
- What is the hard deadline, if any?
- What's in scope vs. explicitly out of scope from a business perspective?
- Are there compliance, security, or legal requirements?
- What would cause this project to be considered a failure?

### Step 3: Tag and prioritize

For every requirement captured:
1. Assign source (Client / Engineering / Leadership)
2. Assign priority (P1 / P2 / P3)
3. Assign type (Functional / Non-Functional)
4. Mark status (Clear / Needs Clarification)

### Step 4: Surface conflicts and gaps

Review all requirements as a set:
- Any P1 from one source that contradicts a P1 from another? → Mark as Conflicted, flag for resolution
- Any implicit dependency that hasn't been stated as a requirement? → Add as a gap item
- Any source that produced zero requirements in a category? → Flag for follow-up

### Step 5: Produce the requirements document

Use `template.md` to format the final output.

## Common Pitfalls

**Requirements without source** — If you can't trace a requirement back to who asked for it, you can't resolve conflicts or deprioritize it later. Tag everything.

**All P1s** — If every requirement is P1, none of them are. Push back: "If you could only deliver 3 things, what are they?"

**Functional only** — Non-functional requirements (load time, uptime, security, WCAG accessibility) are as real as features. Missing them causes launch-blocking issues.

**Resolved conflicts stay in the document** — When a conflict is resolved, update the status. Don't leave "Conflicted" items in a document handed to engineering.

**Requirements stated as solutions** — "We need a dashboard with real-time charts" is a solution. The requirement is "users need to monitor [metric] without a delay." Capture both.

## References

Related skills:
- `transcript-processor` — Extract requirements from Zoom/meeting transcripts before running this skill
- `scope-of-work` — Next step after requirements are structured
- `discovery-interview-prep` (PM-Skills) — Interview techniques for requirement gathering
- `problem-statement` (PM-Skills) — Structuring the problem behind requirements

## Evidence Standards

**NEVER FABRICATE:**
- Never invent requirements that weren't stated or clearly implied by a stakeholder
- Never make up stakeholder quotes
- Never assume a requirement is confirmed without explicit PM validation

**Confidence levels are required for all transcript-sourced requirements:**
- High: explicitly stated in a meeting or transcript
- Medium: implied by a described pain point or outcome
- Low: inferred from context — goes in ambiguities, not requirements

**All requirements must have:**
- Source (Client / Engineering / Leadership)
- Priority (P1 / P2 / P3)
- Type (Functional / Non-Functional)
- Status (Clear / Needs Clarification / Conflicted)

## Mode Detection

Automatically detect which mode applies at the start of a session:
- **Transcript mode:** PM provides a file path or pastes transcript text → run `transcript-processor` 7-layer briefing first, then feed output into this framework
- **Interview mode:** No transcript → work through the 3-source framework interactively, one source at a time
