# Requirements Document — [Project Name]

**Client:** [Client name]
**Date:** [Date]
**PM:** [York IE PM name]
**Status:** Draft / In Review / Approved

---

## Project Context

[One paragraph: what this project is, why it exists, and what success looks like. Keep it to 3-5 sentences.]

---

## Requirements

### Client / Stakeholder Requirements

| # | Requirement | Type | Priority | Status |
|---|---|---|---|---|
| C1 | [Requirement description] | Functional | P1 | Clear |
| C2 | [Requirement description] | Functional | P2 | Needs Clarification |
| C3 | [Requirement description] | Non-Functional | P1 | Clear |

**Open questions from client:**
- [ ] [Question that needs answer before this requirement can be finalized]

---

### Engineering / Design Requirements

| # | Requirement | Type | Priority | Status |
|---|---|---|---|---|
| E1 | [Requirement description] | Non-Functional | P1 | Clear |
| E2 | [Technical constraint description] | Non-Functional | P1 | Clear |
| E3 | [UX/design constraint] | Functional | P2 | Needs Clarification |

**Open questions from engineering/design:**
- [ ] [Question that needs answer before this requirement can be finalized]

---

### Leadership / Executive Requirements

| # | Requirement | Type | Priority | Status |
|---|---|---|---|---|
| L1 | [Strategic requirement or constraint] | Functional | P1 | Clear |
| L2 | [Deadline or resource constraint] | Non-Functional | P1 | Clear |

**Open questions from leadership:**
- [ ] [Question that needs answer before this requirement can be finalized]

---

## Conflicts

| Conflict | Source A | Source B | Resolution |
|---|---|---|---|
| [Description of conflict] | C1: [Client requirement] | E2: [Engineering constraint] | Unresolved — needs decision |

---

## Gaps

Items implied by the requirements but not yet stated explicitly:

- [ ] [Gap description — which requirements imply this, what needs to be confirmed]

---

## Priority Summary

**P1 — Must Have (launch blockers):**
- [List P1 requirements by ID]

**P2 — Should Have (important but not blocking):**
- [List P2 requirements by ID]

**P3 — Nice to Have (future consideration):**
- [List P3 requirements by ID]

---

## Next Steps

- [ ] Resolve conflicts: [list conflicts by ID]
- [ ] Answer open questions: [list by stakeholder]
- [ ] Run `/york-ie:scope [Project Name]` to create Scope of Work
